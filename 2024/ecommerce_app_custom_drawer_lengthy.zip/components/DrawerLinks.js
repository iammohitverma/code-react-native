export const DrawerLinks = [
  { label: "Home", screen: "Home" },
  { label: "Shop", screen: "Shop" },
  { label: "Best Seller", screen: "BestSeller" },
  { label: "Featured Products", screen: "FeaturedProducts" },
  { label: "Categories", screen: "Categories" },
  { label: "Wishlist", screen: "Wishlist" },
  { label: "Single Product", screen: "SingleProduct" },
  { label: "Order", screen: "OrderScreen" },
  { label: "Order History", screen: "OrderHistory" },
  { label: "My Promo Codes", screen: "PromoCodes" },
];
