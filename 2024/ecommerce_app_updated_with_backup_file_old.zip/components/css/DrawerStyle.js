import { StyleSheet } from "react-native";

export const DrawerStyle = StyleSheet.create({
  test: {
    backgroundColor: "red",
  },
});
