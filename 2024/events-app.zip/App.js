import React, { useEffect, useState } from "react";
import { useFonts } from "expo-font";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import SplashScreen from "./components/SplashScreen";
import WelcomeScreen from "./components/WelcomeScreen";
import LoginScreen from "./components/auth/LoginScreen";
import RegisterScreen from "./components/auth/RegisterScreen";
import HomeScreen from "./components/HomeScreen";
import EventsScreen from "./components/EventsScreen";
import BlogScreen from "./components/BlogScreen";
import ProfileScreen from "./components/ProfileScreen";
import SignoutScreen from "./components/SignoutScreen";
import ContactScreen from "./components/ContactScreen";
import { Image } from "react-native";
import BackButton from "./components/BackButton";

const Stack = createNativeStackNavigator();
const BottomTab = createBottomTabNavigator();

function App() {
  const [fontsLoaded] = useFonts({
    "Belleza-Regular": require("./assets/fonts/Belleza/Belleza-Regular.ttf"),
    "DMSans-Black": require("./assets/fonts/DM_Sans/DMSans-Black.ttf"),
    "DMSans-Bold": require("./assets/fonts/DM_Sans/DMSans-Bold.ttf"),
    "DMSans-ExtraBold": require("./assets/fonts/DM_Sans/DMSans-ExtraBold.ttf"),
    "DMSans-ExtraLight": require("./assets/fonts/DM_Sans/DMSans-ExtraLight.ttf"),
    "DMSans-Light": require("./assets/fonts/DM_Sans/DMSans-Light.ttf"),
    "DMSans-Medium": require("./assets/fonts/DM_Sans/DMSans-Medium.ttf"),
    "DMSans-Regular": require("./assets/fonts/DM_Sans/DMSans-Regular.ttf"),
    "DMSans-SemiBold": require("./assets/fonts/DM_Sans/DMSans-Medium.ttf"),
    "DMSans-Thin": require("./assets/fonts/DM_Sans/DMSans-Medium.ttf"),
  });

  useEffect(() => {
    if (fontsLoaded) {
      console.log("Fonts loaded successfully.");
    } else {
      console.log("Fonts are still loading.");
    }
  }, [fontsLoaded]);

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          // headerStyle: { backgroundColor: "red" },
          headerLeftContainerStyle: { paddingLeft: 20 },
        }}
      >
        <Stack.Screen
          name="SplashScreen"
          component={SplashScreen}
          options={{
            title: "SplashScreen",
            header: () => null,
          }}
        />
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Register"
          component={RegisterScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Signout"
          component={SignoutScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="WelcomeScreen"
          component={WelcomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="HomeScreen"
          component={BottomTabsNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="EventsScreen"
          component={BottomTabsNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="BlogScreen"
          component={BottomTabsNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ProfileScreen"
          component={BottomTabsNavigator}
          options={{
            headerShown: true,
            headerLeft: () => <BackButton />,
          }}
        />
        <Stack.Screen
          name="Contact"
          component={ContactScreen}
          options={{
            headerShown: true,
            headerLeft: () => <BackButton />,
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

function BottomTabsNavigator() {
  return (
    <BottomTab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconSource;
          if (route.name === "HomeScreen") {
            iconSource = focused
              ? require("./assets/home_active.png")
              : require("./assets/home.png");
          } else if (route.name === "BlogScreen") {
            iconSource = focused
              ? require("./assets/blogs_active.png")
              : require("./assets/blogs.png");
          } else if (route.name === "ProfileScreen") {
            iconSource = focused
              ? require("./assets/profile_active.png")
              : require("./assets/profile.png");
          } else if (route.name === "EventsScreen") {
            iconSource = focused
              ? require("./assets/events_active.png")
              : require("./assets/events.png");
          }

          return (
            <Image
              source={iconSource}
              style={{
                width: size,
                height: size,
              }}
            />
          );
        },
        tabBarActiveTintColor: "#2F861B",
        tabBarActiveBackgroundColor: "#fff",
        tabBarInactiveTintColor: "#636e72",
        tabBarInactiveBackgroundColor: "#fff",
        tabBarShowLabel: true,
        tabBarShowIcon: true,
        tabBarLabelStyle: { fontSize: 14, marginTop: 0 },
        tabBarIconStyle: {
          fontSize: 14,
          size: 20,
          width: 50,
          height: 35,
          backgroundColor: "transparent",
        },
        tabBarStyle: { paddingVertical: 10, height: 70 },
        headerLeft: () => (
          // route.name !== "HomeScreen" && route.name !== "Signout" ? (
          <BackButton />
        ),
        // ) : null, // Show back button only on specific screens
        // headerStyle: { backgroundColor: "red" },
        headerLeftContainerStyle: { paddingLeft: 20 },
      })}
    >
      <BottomTab.Screen
        name="HomeScreen"
        component={HomeScreen}
        options={{ title: "Home", header: () => null }}
      />
      <BottomTab.Screen
        name="EventsScreen"
        component={EventsScreen}
        options={{ title: "Events", header: () => null }}
      />
      <BottomTab.Screen
        name="BlogScreen"
        component={BlogScreen}
        options={{ title: "Blog", header: () => null }}
      />
      <BottomTab.Screen
        name="ProfileScreen"
        component={ProfileScreen}
        options={{ title: "Profile" }}
      />
    </BottomTab.Navigator>
  );
}

export default App;
