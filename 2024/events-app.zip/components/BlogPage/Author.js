import { useState, useEffect } from "react";
import axios from "axios";
const renderItem = ({ authorid }) => {
  const [Author, setAuthor] = useState(null);

  const Id = authorid;
  useEffect(() => {
    const fetchAllMedia = async () => {
      try {
        // fetch all Post items
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/users/${Id}`
        );
        let items;
        if (Array.isArray(response.data)) {
          items = response.data.map((item) => item);
        } else {
          items = [response.data];
        }
        setAuthor(items);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchAllMedia();
  }, []);
  if (Author != null) {
    return Author[0].name;
  }
};
export default renderItem;
