import { useState, useEffect } from "react";
import {
    View,
    Text,
    ImageBackground,
} from "react-native";
import ThemeStyle from "../css/ThemeStyle";
import axios from "axios";
const renderHeader = ({ data }) => {
    const [MediaItem, setMediaItems] = useState(null);
    const bannerId = data.banner_background_image;

    useEffect(() => {
        const fetchAllMedia = async () => {
            try {
                // Use Promise.all to fetch all media items
                const responses = await axios.get(`https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/media/${bannerId}`);
                if (responses.data.media_details.sizes.large.source_url) {
                    setMediaItems(responses.data.media_details.sizes.large.source_url);
                } else {
                    console.warn("Media not found for banner_bg:");
                }
            } catch (error) {
                setMediaItems('https://bookmyevents.tmdemo.in/bme-admin/wp-content/uploads/2024/12/placeholder.png');
                //console.error("Error fetching data:", error);
            }
        };

        fetchAllMedia();
    }, [bannerId]);
    if (MediaItem != null) {
        return (
      <View style={{ paddingBottom: 40 }}>
        <ImageBackground
          source={{ uri: MediaItem }}
          resizeMode="cover"
          style={ThemeStyle.EventScreenBanner}
        >
          <Text
            style={[
              ThemeStyle.WelcomeScreenHeading,
              { color: "#fff", marginBottom: 0 },
            ]}
          >
          {data.banner_heading}
          </Text>
        </ImageBackground>
      </View>
        );
    }
};

export default renderHeader;