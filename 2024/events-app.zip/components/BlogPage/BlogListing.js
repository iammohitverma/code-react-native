import { useState, useEffect } from "react";
import { View, Text, Image, Pressable } from "react-native";
import ThemeStyle from "../css/ThemeStyle";
import ImgTag from "../global/singleImage";
import Author from "./Author";
import axios from "axios";
const renderItem = ({ data }) => {
  const [PostItem, setPostItems] = useState(null);

  const PostType = data.post_type;
  useEffect(() => {
    const fetchAllMedia = async () => {
      try {
        // fetch all Post items
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/${PostType}`
        );
        let items;
        if (Array.isArray(response.data)) {
          items = response.data.map((item) => item);
        } else {
          items = [response.data];
        }
        setPostItems(items);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchAllMedia();
  }, [PostType]);
  if (PostItem != null) {
    return PostItem.map((item, index) => (
      <Pressable style={ThemeStyle.BlogListingCard} key={index}>
        <View style={ThemeStyle.eventListingCardInner}>
          <ImgTag ImageId={item.featured_media} />
          <View style={ThemeStyle.eventListingCardDetail}>
            <Text style={ThemeStyle.blogTitle}>{item.title.rendered}</Text>
            <Text style={ThemeStyle.publishTime}>{item.date}</Text>
            <View style={ThemeStyle.blogAuthorWrap}>
              <Image
                style={{
                  height: 13,
                  width: 13,
                  marginRight: 5,
                }}
                source={require("../../assets/user_icon2.png")}
                resizeMode="contain"
              />
              <Text style={ThemeStyle.blogAuthor}>
                <Author authorid={item.author} />
              </Text>
            </View>
          </View>
        </View>
      </Pressable>
    ));
  }
};
export default renderItem;
