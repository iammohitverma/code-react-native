import React, { useState } from "react";
import {
  SafeAreaView,
  ScrollView,
  Text,
  View,
  TextInput,
  Image,
  Alert,
  ImageBackground,
  TouchableOpacity,
  ActivityIndicator,
  StatusBar,
} from "react-native";
import ThemeStyle from "./css/ThemeStyle";
import axios from "axios";

const ContactScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    YourName: "",
    YourEmail: "",
    Subject: "",
    Message: "",
  });
  const [success, setSucess] = useState();
  const [loader, setLoader] = useState("");
  const [ResponseMessage, setResponseMessage] = useState("");

  const handleSubmit = async () => {
    if (
      !formData.YourEmail ||
      !formData.YourName ||
      !formData.Subject ||
      !formData.Message
    ) {
      Alert.alert("Error", "Please fill in all fields.");
      return;
    }

    // Perform validation (if needed)
    if (!/\S+@\S+\.\S+/.test(formData.YourEmail)) {
      Alert.alert("Error", "Please enter a valid email address.");
      return;
    }
    setLoader(true);
    const config = {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    };
    const endpoint = `https://bookmyevents.tmdemo.in/bme-admin/wp-json/contact-form-7/v1/contact-forms/203/feedback`;
    const data = new FormData();
    data.append("your-name", formData.YourName);
    data.append("your-email", formData.YourEmail);
    data.append("your-subject", formData.Subject);
    data.append("your-message", formData.Message);
    data.append("_wpcf7_unit_tag", "wpcf7-f203-p0-o1");

    try {
      const response = await axios.post(endpoint, data, config);
      // Alert.alert(response.data.message)
      if (response.data.status === "mail_sent") {
        setResponseMessage(`${response.data.message}`);
        setSucess(true);
        setFormData({
          YourName: "",
          YourEmail: "",
          Subject: "",
          Message: "",
        });
      } else {
        setResponseMessage(`${response.data.message}`);
      }

      setTimeout(() => {
        setResponseMessage("");
        setSucess("");
      }, 4000);
    } catch (error) {
      console.error("Error submitting form:", error);
      setSucess(false);
      setResponseMessage("An error occurred while submitting the form.");
    }
    setLoader(false);
    setTimeout(() => {
      setResponseMessage("");
      setSucess("");
    }, 4000);
  };

  const handleInputChange = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value,
    }));
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={[ThemeStyle.mainWrapper, { flex: 1, alignItems: "center" }]}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
        <ScrollView>
          <View style={{ width: "100%" }}>
            {/* <Image
            style={ThemeStyle.ContactScreenBanner}
            source={require("../assets/contact_banner.png")}
            resizeMode="cover"
          /> */}
            <View style={[ThemeStyle.pb_30, { width: "100%" }]}>
              <View>
                <Text style={ThemeStyle.loginHeader}>Contact Us</Text>
                <Text style={ThemeStyle.loginSubHdng}>
                  Feel free to mesage us
                </Text>
              </View>

              <View style={ThemeStyle.inputWrap}>
                {success === true && (
                  <Text style={ThemeStyle.SuccessMsg}>{ResponseMessage}</Text>
                )}
                {success === false && (
                  <Text style={ThemeStyle.ErrorMsg}>{ResponseMessage}</Text>
                )}
              </View>

              {/* Name */}
              <View style={ThemeStyle.inputWrap}>
                <Image
                  source={require("../assets/user.png")}
                  style={ThemeStyle.fieldIcon}
                />
                <TextInput
                  style={ThemeStyle.globalInput}
                  placeholder="Enter Your Name"
                  placeholderTextColor="#d3d0d1"
                  value={formData.YourName}
                  onChangeText={(text) => handleInputChange("YourName", text)}
                  // editable={!loader} // Disable the field when loader is true
                />
              </View>

              {/* Email */}
              <View style={ThemeStyle.inputWrap}>
                <Image
                  source={require("../assets/email.png")}
                  style={ThemeStyle.fieldIcon}
                />
                <TextInput
                  style={ThemeStyle.globalInput}
                  placeholder="Enter Your Email"
                  placeholderTextColor="#d3d0d1"
                  value={formData.YourEmail}
                  onChangeText={(text) => handleInputChange("YourEmail", text)}
                  // editable={!loader} // Disable the field when loader is true
                />
              </View>

              {/* Subject */}
              <View style={ThemeStyle.inputWrap}>
                <Image
                  source={require("../assets/subject.png")}
                  style={ThemeStyle.fieldIcon}
                />
                <TextInput
                  style={ThemeStyle.globalInput}
                  placeholder="Enter Subject"
                  placeholderTextColor="#d3d0d1"
                  value={formData.Subject}
                  onChangeText={(text) => handleInputChange("Subject", text)}
                  // editable={!loader} // Disable the field when loader is true
                />
              </View>

              {/* Message */}
              <View style={ThemeStyle.inputWrap}>
                <Image
                  source={require("../assets/messages.png")}
                  style={ThemeStyle.fieldIcon}
                />
                <TextInput
                  style={ThemeStyle.globalInput}
                  placeholder="Enter Your Message"
                  placeholderTextColor="#d3d0d1"
                  value={formData.Message}
                  onChangeText={(text) => handleInputChange("Message", text)}
                  // editable={!loader} // Disable the field when loader is true
                />
              </View>

              {/* Submit */}
              <View style={ThemeStyle.inputWrap}>
                <ImageBackground
                  source={require("../assets/button.png")} // Adjust the path to your image
                  style={ThemeStyle.submitBtnBG}
                >
                  <TouchableOpacity
                    onPress={handleSubmit}
                    style={ThemeStyle.submitBtn}
                  >
                    <Text style={ThemeStyle.submitBtnText}>Send Message</Text>
                  </TouchableOpacity>
                </ImageBackground>
              </View>

              {loader && (
                <View style={ThemeStyle.loaderScreen}>
                  <ActivityIndicator size="large" color="#ffffff" />
                </View>
              )}
            </View>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export default ContactScreen;
