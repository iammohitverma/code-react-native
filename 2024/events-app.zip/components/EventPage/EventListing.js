import { useState, useEffect } from "react";
import { View, Text, Image, Pressable } from "react-native";
import ThemeStyle from "../css/ThemeStyle";
import ImgTag from "../global/singleImage";
import axios from "axios";
const renderItem = ({ data }) => {
  const [PostItem, setPostItems] = useState(null);

  const PostType = data.post_type;
  useEffect(() => {
    const fetchAllMedia = async () => {
      try {
        // fetch all Post items
        const currentDate = new Date();
        const normalizedCurrentDate = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate()
        ); // Normalize current date to remove time
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/${PostType}/?per_page=50`
        );
        const filtered = response.data.filter((item) => {
          const isCategoryMatch = item["events-category"]?.some(
            (cat) => cat === 3
          );
          const isUpcomingDateValid = item.acf?.sections?.some((section) => {
            if (
              section.acf_fc_layout === "upcoming_event" &&
              section.upcoming_event_date
            ) {
              const dateStr = section.upcoming_event_date;
              const eventDate = new Date(
                parseInt(dateStr.slice(0, 4)), // Year
                parseInt(dateStr.slice(4, 6)) - 1, // Month (0-based)
                parseInt(dateStr.slice(6, 8)) // Day
              );
              const normalizedEventDate = new Date(
                eventDate.getFullYear(),
                eventDate.getMonth(),
                eventDate.getDate()
              );

              return normalizedEventDate >= normalizedCurrentDate; // Compare normalized dates
            }
            return false;
          });
          return isCategoryMatch && isUpcomingDateValid;
        });
        setPostItems(filtered);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchAllMedia();
  }, [PostType]);
  if (PostItem != null) {
    return PostItem.map((item, index) => (
      <Pressable style={ThemeStyle.eventListingCard} key={index}>
        <View style={ThemeStyle.eventListingCardInner}>
          {/* <Image
                style={{
                    height: 100,
                    width: 80,
                    marginRight: 10,
                    borderRadius: 10,
                }}
                source={item.eventFeaturedImage}
                resizeMode="cover"
            /> */}
          <ImgTag ImageId={item.featured_media} />
          <View style={ThemeStyle.eventListingCardDetail}>
            {item.acf.sections &&
              Array.isArray(item.acf.sections) &&
              item.acf.sections
                .filter((section) => section.acf_fc_layout === "post_fields")
                .map((post_fields_section, index) => {
                  const formatDate = (dateStr, timeStr) => {
                    const year = dateStr.slice(0, 4);
                    const month = dateStr.slice(4, 6) - 1; // Month is zero-based in JS
                    const day = dateStr.slice(6, 8);
                    const hours = timeStr.slice(0, 2);
                    const minutes = timeStr.slice(3, 5);

                    const date = new Date(year, month, day, hours, minutes);
                    const monthName = date.toLocaleString("en-US", {
                      month: "short",
                    }); // Aug, Sep, etc.
                    const dayOfMonth = date.getDate();
                    let hours12 = date.getHours() % 12 || 12; // Convert to 12-hour format
                    const minutesFormatted = date
                      .getMinutes()
                      .toString()
                      .padStart(2, "0"); // Format minutes as 2 digits
                    const ampm = date.getHours() >= 12 ? "PM" : "AM";
                    return `${monthName} ${dayOfMonth} | ${hours12}:${minutesFormatted} ${ampm}`;
                  };
                  const startDateTime = formatDate(
                    post_fields_section.start_date,
                    post_fields_section.start_time
                  );
                  const endDateTime = formatDate(
                    post_fields_section.end_date,
                    post_fields_section.end_time
                  );

                  return (
                    <Text key={index} style={ThemeStyle.eventTime}>
                      {startDateTime} - {endDateTime}
                    </Text>
                  );
                })}
            <Text style={ThemeStyle.eventTitle}>{item.title.rendered}</Text>
            <View style={ThemeStyle.eventLocationWrap}>
              <Image
                style={{
                  height: 14,
                  width: 14,
                  marginRight: 5,
                  borderRadius: 10,
                }}
                source={require("../../assets/map_pin.png")}
                resizeMode="contain"
              />
              {item.acf.sections &&
                Array.isArray(item.acf.sections) &&
                item.acf.sections
                  .filter((section) => section.acf_fc_layout === "post_fields")
                  .map((post_fields_section, index) => {
                    return (
                      <Text style={ThemeStyle.eventLocation} key={index}>
                        {post_fields_section.loaction}
                      </Text>
                    );
                  })}
            </View>
          </View>
        </View>
      </Pressable>
    ));
  }
};
export default renderItem;
