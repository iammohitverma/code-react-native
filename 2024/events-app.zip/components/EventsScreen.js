import { useState, useEffect } from "react";
import { SafeAreaView, StatusBar, View, SectionList, ActivityIndicator } from "react-native";
import Header from "./Header";
import Banner from "./EventPage/Banner";
import EventListing from "./EventPage/EventListing";
import axios from "axios";
const EventsScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [acfData, setAcfData] = useState(null);
  const [bannerData, setbannerData] = useState(null);
  const [eventsData, seteventsData] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/pages/`
        );
        const currentPage = response.data.find(
          (item) => item.title && item.title.rendered === "Events"
        );
        if (currentPage && currentPage.acf) {
          setAcfData(currentPage.acf);
        } else {
          setError(`No ACF data found for page: ${PageName}`);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setError("Failed to fetch data.");
      }
    };
    fetchData();
  }, []);
  useEffect(() => {
    if (acfData != null) {
      setbannerData(acfData.sections[0]);
      seteventsData(acfData.sections[1]);
      setLoading(false);
    }
  }, [acfData]);

  
    const SECTIONS = [
      {
        title: "Header",
        data: [{ component: <Header navigation={navigation} /> }],
      },
      {
        title: "Banner",
        data: bannerData ? [{ component: <Banner data={bannerData} /> }] : [],
      },
      {
        title: "EventListing",
        data: eventsData
          ? [{ component: <EventListing data={eventsData} /> }]
          : [],
      },
    ];
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
        <View style={{ flex: 1, backgroundColor: "#fff" }}>
          <StatusBar backgroundColor="#fff" barStyle="dark-content" />
          {loading ? (
                            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                            <ActivityIndicator size="large" color="#0000ff" />
                          </View>
                        ) : (
          <SectionList
            sections={SECTIONS}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => <View>{item.component}</View>}
            showsVerticalScrollIndicator={false}
          />
                        )}
        </View>
      </SafeAreaView>
    );
};
export default EventsScreen;
