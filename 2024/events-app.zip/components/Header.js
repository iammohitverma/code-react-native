import { View, Image, Pressable } from "react-native";
import ThemeStyle from "./css/ThemeStyle";
import { useNavigation } from "@react-navigation/native";

const Header = () => {
  const navigation = useNavigation(); // Get the navigation objectavigation

  return (
    <View style={ThemeStyle.HeaderWrap}>
      <View style={ThemeStyle.headerInner}>
        <View style={ThemeStyle.logoWrap}>
          <Pressable onPress={() => navigation.navigate("HomeScreen")}>
            <Image
              style={{ height: "50", width: "150" }}
              source={require("../assets/icon.png")}
              resizeMode="contain"
            />
          </Pressable>
        </View>
        <View style={ThemeStyle.HeaderIcons}>
          <Pressable
            style={ThemeStyle.br_10}
            onPress={() => navigation.navigate("ProfileScreen")}
          >
            <Image
              style={{ height: "30", width: "30" }}
              source={require("../assets/profile_image.png")}
              resizeMode="contain"
            />
          </Pressable>
          <Pressable
            style={ThemeStyle.br_10}
            onPress={() => navigation.navigate("ProfileScreen")}
          >
            <Image
              style={{ height: "30", width: "30" }}
              source={require("../assets/bell_icon.png")}
              resizeMode="contain"
            />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

export default Header;
