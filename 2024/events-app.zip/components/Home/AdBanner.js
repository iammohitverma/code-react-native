import { View, Image } from "react-native";

const AdBanner = () => {
  return (
    <View>
      <Image
        style={{ height: "80", width: "100%" }}
        source={require("../../assets/ad_banner.png")}
        resizeMode="cover"
      />
    </View>
  );
};

export default AdBanner;
