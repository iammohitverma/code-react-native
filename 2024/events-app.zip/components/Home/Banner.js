import { useState, useEffect } from "react";
import { Text, View, Image } from "react-native";
import axios from "axios";
import Swiper from "react-native-swiper";
const Banner = ({ data }) => {
  const [MediaItem, setMediaItems] = useState([]);
  const bannerIds = data;

  useEffect(() => {
    const fetchAllMedia = async () => {
      try {
        // Use Promise.all to fetch all media items
        const responses = await Promise.all(
          bannerIds.map((bannerId) =>
            axios.get(
              `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/media/${bannerId}`
            )
          )
        );
        const items = responses.map((response) => response.data);
        setMediaItems(items);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchAllMedia();
  }, []);
  return (
    <View>
      <Swiper
        showsButtons={false}
        showsPagination={false}
        style={{ height: "350" }}
        index={0}
        loop={false}
      >
        {MediaItem.map((item, index) => (
          <View key={index}>
            <Image
              style={{ width: "100%", height: "350" }}
              //  source={{ uri: item.guid.rendered }}
              source={{ uri: item.media_details.sizes.medium.source_url }}
              resizeMode="cover"
            />
          </View>
        ))}
      </Swiper>
    </View>
  );
};

export default Banner;
