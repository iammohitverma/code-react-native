import { useState, useEffect } from "react";
import { View, Text, Image, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import ThemeStyle from "../css/ThemeStyle";
import axios from 'axios';
import { SvgUri } from 'react-native-svg';
const CategoryIcons = ({data}) => {
  const [MediaItem, setMediaItems] = useState([]);
useEffect(() => {
  const fetchAllMedia = async () => {
    try {
      const responses = await Promise.all(
        data.map((data) =>
          axios.get(`https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/media/${data.icon}`)
        )
      );
       const items = responses.map((response) => response.data);
      
      setMediaItems(items);
      
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  fetchAllMedia();
}, []);

 
  if(MediaItem!= ''){
  return (
    <SafeAreaView>
      <View style={ThemeStyle.categoryIconsWrapper}>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          
          {MediaItem.map((item, index) => (
            <View key={index} style={ThemeStyle.categoryIconBox}>
              <SvgUri
               height = '55'
              width = '55'
              uri = {item.guid.rendered}
              />
              <Text style={ThemeStyle.fs_12_600}>{data[index].title}</Text>
            </View>
          ))}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}
};

export default CategoryIcons;
