import { useState, useEffect } from "react";
import {
  View,
  Text,
  Image,
  ScrollView,
  Pressable,
  ImageBackground,
  FlatList,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import axios from "axios";
import ThemeStyle from "../css/ThemeStyle";
import ImgTag from "../global/singleImage";

const EventThisWeek = ({ data }) => {
  const [filteredData, setFilteredData] = useState([]);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentDate = new Date();
        const normalizedCurrentDate = new Date(
          currentDate.getFullYear(),
          currentDate.getMonth(),
          currentDate.getDate()
        );
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/${data.post_type_name}/?per_page=50`
        );
        const filtered = response.data.filter((item) => {
          const isCategoryMatch = item["events-category"]?.some(
            (cat) => cat === data.upcoming_events[0]
          );

          // Check if upcoming_event_date is greater than the current date
          const isUpcomingDateValid = item.acf?.sections?.some((section) => {
            if (
              section.acf_fc_layout === "upcoming_event" &&
              section.upcoming_event_date
            ) {
              const dateStr = section.upcoming_event_date;
              const eventDate = new Date(
                parseInt(dateStr.slice(0, 4)), // Year
                parseInt(dateStr.slice(4, 6)) - 1, // Month (0-based)
                parseInt(dateStr.slice(6, 8)) // Day
              );
              const normalizedEventDate = new Date(
                eventDate.getFullYear(),
                eventDate.getMonth(),
                eventDate.getDate()
              );

              return normalizedEventDate >= normalizedCurrentDate; // Compare normalized dates
            }
            return false;
          });
          return isCategoryMatch && isUpcomingDateValid;
        });
        setFilteredData(filtered);
        // console.log('Filtered Data:', filteredData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [data]);

  const formatDate = (date) => {
    const options = {
      weekday: "short",
      day: "numeric",
      month: "short",
      year: "numeric",
    };
    return date.toLocaleDateString("en-US", options);
  };
  // Function to get tomorrow's date
  const getTomorrowDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return formatDate(tomorrow);
  };

  // Function to get the upcoming weekend (next Saturday-Sunday)
  const getWeekendDates = () => {
    const weekendStart = new Date();
    const weekendEnd = new Date();
    weekendStart.setDate(
      weekendStart.getDate() + ((6 - weekendStart.getDay()) % 7)
    ); // next Saturday
    weekendEnd.setDate(weekendStart.getDate() + 1); // next Sunday
    return `${formatDate(weekendStart)} - ${formatDate(weekendEnd)}`;
  };

  // Function to get the current month name
  const getCurrentMonth = () => {
    const month = new Date();
    const options = { month: "short", year: "numeric" }; // Short month format with year
    return month.toLocaleDateString("en-US", options); // Format it as "Aug 2023"
  };

  const getTodayAndTomorrow = () => {
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1); // Get tomorrow's date

    return { today, tomorrow };
  };

  // Function to check if a date is on the upcoming weekend (Saturday or Sunday)
  const isWeekend = (date) => {
    const day = date.getDay();
    const today = new Date();
    const saturday = new Date(today);
    const sunday = new Date(today);

    saturday.setDate(today.getDate() + ((6 - today.getDay() + 7) % 7));
    sunday.setDate(saturday.getDate() + 1);

    if (
      saturday.toDateString() == date.toDateString() ||
      sunday.toDateString() == date.toDateString()
    ) {
      return day === 6 || day === 0;
    }
  };

  const categorizeEvents = (events) => {
    const { today, tomorrow } = getTodayAndTomorrow();

    const eventsData = {
      Today: [],
      Tomorrow: [],
      Weekend: [],
      Month: [],
    };

    events.forEach((event) => {
      event.acf.sections &&
        Array.isArray(event.acf.sections) &&
        event.acf.sections
          .filter((section) => section.acf_fc_layout === "upcoming_event")
          .map((upcoming_event) => {
            if (upcoming_event.upcoming_event_date) {
              const dateStr = `${upcoming_event.upcoming_event_date.slice(
                0,
                4
              )}-${upcoming_event.upcoming_event_date.slice(
                4,
                6
              )}-${upcoming_event.upcoming_event_date.slice(6, 8)}`;
              const date = new Date(dateStr);

              // Now we check the date
              if (date.toDateString() === today.toDateString()) {
                eventsData.Today.push(event);
              } else if (date.toDateString() === tomorrow.toDateString()) {
                eventsData.Tomorrow.push(event);
              } else if (isWeekend(date)) {
                eventsData.Weekend.push(event);
              }
              if (date.getMonth() === today.getMonth()) {
                eventsData.Month.push(event);
              }
            }
          });
    });

    return eventsData;
  };
  const categorizedEvents = categorizeEvents(filteredData);

  //  Categories Data
  const Categories_Data = [
    {
      cat: "Month",
      date: getCurrentMonth(),
    },
    {
      cat: "Today",
      date: formatDate(new Date()),
    },
    {
      cat: "Tomorrow",
      date: getTomorrowDate(),
    },
    {
      cat: "Weekend",
      date: getWeekendDates(),
    },
  ];
  const [activeIndex, setActiveIndex] = useState(0);

  // catFilter
  const catFilter = (index) => {
    setActiveIndex(index);
  };

  //  Post Listing Data
  const cate = Categories_Data[activeIndex].cat;
  const Posts_Data_new = categorizedEvents[cate];

  return (
    <SafeAreaView>
      <View style={[ThemeStyle.pt_30, ThemeStyle.pb_10]}>
        <View style={ThemeStyle.px_20}>
          <Text style={[ThemeStyle.fs_16_500, ThemeStyle.mb_20]}>
            {data.section_heading}
          </Text>
        </View>
        {/* Event Category buttons */}
        <View style={ThemeStyle.categoryBtnsWrapper}>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            {Categories_Data.map((item, index) => (
              <Pressable
                key={index}
                onPress={() => catFilter(index)}
                style={[ThemeStyle.categoryBtn]}
              >
                <ImageBackground
                  source={
                    index === activeIndex
                      ? require("../../assets/button_bg.png")
                      : require("../../assets/button_bg_white.png")
                  }
                  resizeMode="cover"
                >
                  <View style={ThemeStyle.categoryBtnInner}>
                    <Image
                      style={{ height: 25, width: 25, marginRight: 10 }}
                      source={
                        index === activeIndex
                          ? require("../../assets/calendar_white.png")
                          : require("../../assets/calendar.png")
                      }
                      resizeMode="cover"
                    />
                    <View>
                      <Text
                        style={[
                          ThemeStyle.fs_12_600,
                          index === activeIndex
                            ? ThemeStyle.white
                            : ThemeStyle.grey,
                        ]}
                      >
                        {item.cat}
                      </Text>
                      <Text
                        style={[
                          ThemeStyle.fs_12_400,
                          index === activeIndex
                            ? ThemeStyle.white
                            : ThemeStyle.grey,
                        ]}
                      >
                        {item.date}
                      </Text>
                    </View>
                  </View>
                </ImageBackground>
              </Pressable>
            ))}
          </ScrollView>
        </View>
        {/* Event Listing */}
        <View style={ThemeStyle.eventsListingWrapper}>
          <FlatList
            data={Posts_Data_new}
            keyExtractor={(item, index) => index.toString()}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <Pressable style={ThemeStyle.eventListingCard}>
                <View style={ThemeStyle.eventListingCardInner}>
                  <ImgTag ImageId={item.featured_media} />
                  {/* <Image
                    style={{
                      height: 100,
                      width: 80,
                      marginRight: 10,
                      borderRadius: 10,
                    }}
                    // source={item.eventFeaturedImage}
                    source={require("../../assets/map_pin.png")}
                    resizeMode="cover"
                  /> */}
                  <View style={ThemeStyle.eventListingCardDetail}>
                    {item.acf.sections &&
                      Array.isArray(item.acf.sections) &&
                      item.acf.sections
                        .filter(
                          (section) => section.acf_fc_layout === "post_fields"
                        )
                        .map((post_fields_section, index) => {
                          const formatDate = (dateStr, timeStr) => {
                            const year = dateStr.slice(0, 4);
                            const month = dateStr.slice(4, 6) - 1; // Month is zero-based in JS
                            const day = dateStr.slice(6, 8);
                            const hours = timeStr.slice(0, 2);
                            const minutes = timeStr.slice(3, 5);

                            const date = new Date(
                              year,
                              month,
                              day,
                              hours,
                              minutes
                            );

                            // Custom format: 'Month Day | Time'
                            const monthName = date.toLocaleString("en-US", {
                              month: "short",
                            }); // Aug, Sep, etc.
                            const dayOfMonth = date.getDate();
                            let hours12 = date.getHours() % 12 || 12; // Convert to 12-hour format
                            const minutesFormatted = date
                              .getMinutes()
                              .toString()
                              .padStart(2, "0"); // Format minutes as 2 digits
                            const ampm = date.getHours() >= 12 ? "PM" : "AM";
                            return `${monthName} ${dayOfMonth} | ${hours12}:${minutesFormatted} ${ampm}`;
                          };

                          const startDateTime = formatDate(
                            post_fields_section.start_date,
                            post_fields_section.start_time
                          );
                          const endDateTime = formatDate(
                            post_fields_section.end_date,
                            post_fields_section.end_time
                          );

                          return (
                            <Text key={index} style={ThemeStyle.eventTime}>
                              {startDateTime} - {endDateTime}
                            </Text>
                          );
                        })}
                    <Text style={ThemeStyle.eventTitle}>
                      {item.title.rendered}
                    </Text>
                    <View style={ThemeStyle.eventLocationWrap}>
                      <Image
                        style={{
                          height: 14,
                          width: 14,
                          marginRight: 5,
                          borderRadius: 10,
                        }}
                        source={require("../../assets/map_pin.png")}
                        resizeMode="contain"
                      />
                      {item.acf.sections &&
                        Array.isArray(item.acf.sections) &&
                        item.acf.sections
                          .filter(
                            (section) => section.acf_fc_layout === "post_fields"
                          )
                          .map((post_fields_section, index) => {
                            return (
                              <Text
                                style={ThemeStyle.eventLocation}
                                key={index}
                              >
                                {post_fields_section.loaction}
                              </Text>
                            );
                          })}
                    </View>
                  </View>
                </View>
              </Pressable>
            )}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

export default EventThisWeek;
