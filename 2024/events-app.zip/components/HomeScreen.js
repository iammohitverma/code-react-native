import { useState, useEffect } from "react";
import { View, StatusBar, SectionList, SafeAreaView, ActivityIndicator } from "react-native";
import Header from "./Header";
import Banner from "./Home/Banner";
import CategoryIcons from "./Home/CategoryIcons";
import AdBanner from "./Home/AdBanner";
import EventThisWeek from "./Home/EventThisWeek";
import axios from "axios";

const HomeScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  // // prevent user to go back agter login in both android & ios
  // useEffect(() => {
  //   const unsubscribe = navigation.addListener("beforeRemove", (e) => {
  //     e.preventDefault(); // Prevent navigation
  //     // You can also show a confirmation dialog here before navigating away
  //   });

  //   return unsubscribe; // Cleanup when the component is unmounted
  // }, [navigation]);

  // React.useEffect(() => {
  //   const onBackPress = () => {
  //     Alert.alert(
  //       "Exit App",
  //       "Do you want to exit?",
  //       [
  //         {
  //           text: "Cancel",
  //           onPress: () => {
  //             // Do nothing
  //           },
  //           style: "cancel",
  //         },
  //         { text: "YES", onPress: () => BackHandler.exitApp() },
  //       ],
  //       { cancelable: false }
  //     );

  //     return true;
  //   };

  //   const backHandler = BackHandler.addEventListener(
  //     "hardwareBackPress",
  //     onBackPress
  //   );

  //   return () => backHandler.remove();
  // }, []);
  const [acfData, setAcfData] = useState(null);
  const [error, setError] = useState(null);
  const [bannerData, setbannerData] = useState(null);
  const [categoryData, setcategoryData] = useState(null);
  const [eventsData, seteventsData] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/pages/`
        );
        const currentPage = response.data.find(
          (item) => item.title && item.title.rendered === "Home"
        );
        if (currentPage && currentPage.acf) {
          setAcfData(currentPage.acf);
        } else {
          setError(`No ACF data found for page: ${PageName}`);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        setError("Failed to fetch data.");
      }
    };
    fetchData();
  }, []);
  useEffect(() => {
    if (acfData != null) {
      setbannerData(acfData.sections[0].image_block);
      setcategoryData(acfData.sections[1].type_blocks);
      seteventsData(acfData.sections[2]);
      setLoading(false);
    }
  }, [acfData]);

  const SECTIONS = [
    {
      title: "Header",
      data: [{ component: <Header navigation={navigation} /> }],
    },
    {
      title: "Banner",
      data: bannerData ? [{ component: <Banner data={bannerData} /> }] : [],
    },
    {
      title: "Category Icons",
      data: categoryData
        ? [{ component: <CategoryIcons data={categoryData} /> }]
        : [],
    },
    {
      title: "Ad Banner",
      data: [{ component: <AdBanner /> }],
    },
    {
      title: "Event This Week",
      data: eventsData
        ? [{ component: <EventThisWeek data={eventsData} /> }]
        : [],
    },
    {
      title: "Ad Banner",
      data: [{ component: <AdBanner /> }],
    },
  ];
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={{ flex: 1, backgroundColor: "#fff" }}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
         {loading ? (
          <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
          <ActivityIndicator size="large" color="#0000ff" />
        </View>
      ) : (
        <SectionList
          sections={SECTIONS}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => <View>{item.component}</View>}
          showsVerticalScrollIndicator={false}
        />
        )}
      </View>
    </SafeAreaView>
  );
};
export default HomeScreen;
