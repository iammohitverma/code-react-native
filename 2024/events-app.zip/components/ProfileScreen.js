import { useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  SafeAreaView,
  View,
  StatusBar,
  Image,
  Text,
  TouchableOpacity,
  FlatList,
} from "react-native";
import ThemeStyle from "./css/ThemeStyle";

const ProfileScreen = ({ navigation }) => {
  const [userName, setUserName] = useState();
  useEffect(() => {
    const getUserDetails = async () => {
      try {
        const nameValue = await AsyncStorage.getItem("userName");
        if (nameValue !== null) {
          setUserName(nameValue);
        } else {
          console.log("No userName found in AsyncStorage");
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    getUserDetails();
  }, []);

  const UserMenu = [
    {
      icon: require("../assets/contact.png"),
      text: "Contact Us",
      screen: "Contact",
    },
    {
      icon: require("../assets/signout.png"),
      text: "Sign Out",
      screen: "Signout",
    },
  ];
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={{ flex: 1, backgroundColor: "#fff" }}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
        <View style={ThemeStyle.ProfileScreenHeader}>
          <Image
            style={{ height: "80", width: "80" }}
            source={require("../assets/profile_icon.png")}
            resizeMode="cover"
          />
          <Text style={ThemeStyle.ProfileScreenName}>{userName}</Text>
        </View>
        <View style={ThemeStyle.ProfileScreenMenuWrap}>
          <FlatList
            data={UserMenu}
            renderItem={({ item, index }) => (
              <TouchableOpacity
                style={ThemeStyle.ProfileScreenMenuBtn}
                onPress={() => navigation.navigate(item.screen)}
              >
                <Image
                  style={{ height: "25", width: "25", marginRight: 15 }}
                  source={item.icon}
                  resizeMode="cover"
                />
                <Text style={ThemeStyle.ProfileScreenMenuText}>
                  {item.text}
                </Text>
              </TouchableOpacity>
            )}
            keyExtractor={(item, index) => index}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};
export default ProfileScreen;
