import { useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SignoutScreen = ({ navigation }) => {
  useEffect(() => {
    const handleSignout = async () => {
      await AsyncStorage.clear(); // Clear all stored data
      navigation.reset({
        index: 0,
        routes: [{ name: "Login" }], // Redirect to Login screen
      });
    };

    handleSignout();
  }, [navigation]);
};

export default SignoutScreen;
