import {
  SafeAreaView,
  Text,
  View,
  Pressable,
  Image,
  StatusBar,
  ImageBackground,
  ScrollView,
} from "react-native";
import ThemeStyle from "./css/ThemeStyle";

const WelcomeScreen = ({ navigation }) => {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={ThemeStyle.WelcomeScreenWrapper}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
        <ScrollView>
          <View>
            <Image
              style={ThemeStyle.WelcomeScreenBanner}
              source={require("../assets/welcome_banner.png")}
              resizeMode="cover"
            />
            <View style={ThemeStyle.WelcomeScreenTextWrap}>
              <Text style={ThemeStyle.WelcomeScreenHeading}>
                Find your favourite event here
              </Text>
              <Text style={ThemeStyle.WelcomeScreenSubHdng}>
                Discover events you'll love and create unforgettable memories.
              </Text>
              <Pressable
                style={ThemeStyle.br_10}
                onPress={() => navigation.navigate("Login")}
              >
                <ImageBackground
                  source={require("../assets/button_bg.png")}
                  resizeMode="cover"
                >
                  <Text style={ThemeStyle.GradientButton}>Get Started</Text>
                </ImageBackground>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export default WelcomeScreen;
