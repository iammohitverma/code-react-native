import React, { useState, useEffect } from "react";
import {
  SafeAreaView,
  Text,
  View,
  TextInput,
  Image,
  Alert,
  ImageBackground,
  TouchableOpacity,
  ActivityIndicator,
  StatusBar,
} from "react-native";
import ThemeStyle from "../css/ThemeStyle";
import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";

const LoginScreen = ({ navigation }) => {
  useEffect(() => {
    const checkToken = async () => {
      const token = await AsyncStorage.getItem("token");
      if (token) {
        // Navigate to Dashboard
        navigation.reset({
          index: 0,
          routes: [{ name: "HomeScreen" }], // Redirect to HomeScreen
        });
      }
    };

    checkToken(); // Call the function to check token
  }, [navigation]); // Re-run the effect if navigation changes

  const [emailOrUsername, setEmailOrUsername] = useState("");
  const [password, setPassword] = useState("");
  const [success, setSucess] = useState("");
  const [loader, setLoader] = useState(false);

  const handleSubmit = async () => {
    setSucess(false);
    if (!emailOrUsername || !password) {
      Alert.alert("Error", "Please fill in all fields.");
      return;
    }

    // Perform validation (if needed)
    if (
      emailOrUsername.includes("@") &&
      !/\S+@\S+\.\S+/.test(emailOrUsername)
    ) {
      Alert.alert("Error", "Please enter a valid email address.");
      return;
    }

    // Alert.alert('Success', `Email/Username: ${emailOrUsername}\nPassword: ${'*'.repeat(password.length)}`);
    setLoader(true);
    try {
      const response = await axios.post(
        `https://bookmyevents.tmdemo.in/bme-admin/wp-json/jwt-auth/v1/token`,
        {
          username: emailOrUsername,
          password: password,
        }
      );

      // Alert.alert('Success', JSON.stringify(response.data));
      // Save the JWT token and user info using AsyncStorage
      await AsyncStorage.setItem("token", response.data.token);
      await AsyncStorage.setItem("userName", response.data.user_display_name);
      // Reset the navigation stack and navigate to the dashboard
      setLoader(false);
      setSucess(false);

      // Navigate to Dashboard
      navigation.reset({
        index: 0,
        routes: [{ name: "HomeScreen" }],
      });
    } catch (error) {
      // Alert.alert('Error', error.response?.data?.message || 'Something went wrong');
      setEmailOrUsername("");
      setPassword("");
      setLoader(false);
      setSucess(true);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={[ThemeStyle.mainWrapper, { flex: 1, alignItems: "center" }]}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
        <View>
          <Image
            source={require("../../assets/main-logo.png")}
            style={ThemeStyle.mainLogo}
          />
        </View>

        <View>
          <Text style={ThemeStyle.loginHeader}>Welcome Back!</Text>
          <Text style={ThemeStyle.loginSubHdng}>
            Use Credentials to access your account
          </Text>
        </View>

        {/* Error message display */}
        {success && (
          <View style={ThemeStyle.inputWrap}>
            <Text style={ThemeStyle.ErrorMsg}>
              Invalid username or password.
            </Text>
          </View>
        )}

        {/* Username & Email */}
        <View style={ThemeStyle.inputWrap}>
          <Image
            source={require("../../assets/user.png")}
            style={ThemeStyle.fieldIcon}
          />
          <TextInput
            style={ThemeStyle.globalInput}
            placeholder="Enter email or username"
            placeholderTextColor="#d3d0d1"
            value={emailOrUsername}
            onChangeText={setEmailOrUsername}
            editable={!loader} // Disable the field when loader is true
          />
        </View>

        {/* Password */}
        <View style={ThemeStyle.inputWrap}>
          <Image
            source={require("../../assets/pass.png")}
            style={ThemeStyle.fieldIcon}
          />
          <TextInput
            style={ThemeStyle.globalInput}
            placeholder="Enter your password"
            placeholderTextColor="#d3d0d1"
            value={password}
            onChangeText={setPassword}
            secureTextEntry // Hides the password input
            editable={!loader} // Disable the field when loader is true
          />
        </View>

        {/* Forgot Password */}
        <View style={[ThemeStyle.inputWrap, ThemeStyle.forgotWrap]}>
          <TouchableOpacity
            onPress={() => navigation.navigate("ForgotPassword")}
            style={ThemeStyle.forgotPassword}
          >
            <Text style={ThemeStyle.forgotPasswordText}>
              {" "}
              Forgot Password ?
            </Text>
          </TouchableOpacity>
        </View>

        {/* Submit */}
        <View style={ThemeStyle.inputWrap}>
          <ImageBackground
            source={require("../../assets/button.png")} // Adjust the path to your image
            style={ThemeStyle.submitBtnBG}
          >
            <TouchableOpacity
              onPress={handleSubmit}
              style={ThemeStyle.submitBtn}
            >
              <Text style={ThemeStyle.submitBtnText}>Login</Text>
            </TouchableOpacity>
          </ImageBackground>
        </View>

        <View style={ThemeStyle.loginUnderWrap}>
          <Text style={ThemeStyle.loginUnderText}>Don't have an account?</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate("Register")}
            style={ThemeStyle.loginUnderTouchableArea}
          >
            <Text style={ThemeStyle.signupUnderLogin}> Signup</Text>
          </TouchableOpacity>
        </View>

        {/* Loader display on submit click */}
        {loader && (
          <View style={ThemeStyle.loaderScreen}>
            <ActivityIndicator size="large" color="#ffffff" />
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

export default LoginScreen;
