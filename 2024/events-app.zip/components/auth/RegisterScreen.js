import React, { useState } from "react";
import {
  SafeAreaView,
  StatusBar,
  Text,
  View,
  TextInput,
  Image,
  Alert,
  ScrollView,
  ImageBackground,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import ThemeStyle from "../css/ThemeStyle";
import axios from "axios";
const RegisterScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    firstname: "",
    lastname: "",
    username: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    address: "",
    gender: "",
    city: "",
    state: "",
    pin_code: "",
    country: "",
    bloodgroup: "",
    emergencyname: "",
    emergencynumber: "",
    whatsapp: "",
    tshirt: "",
  });
  const [loader, setLoader] = useState(false);
  const handleSubmit = async () => {
    const {
      firstname,
      lastname,
      username,
      email,
      phone,
      password,
      confirmPassword,
      address,
      gender,
      city,
      state,
      pin_code,
      country,
      bloodgroup,
      emergencyname,
      emergencynumber,
      whatsapp,
      tshirt,
    } = formData;

    if (
      !firstname ||
      !lastname ||
      !username ||
      !email ||
      !phone ||
      !password ||
      !confirmPassword ||
      !address ||
      !gender ||
      !city ||
      !state ||
      !pin_code ||
      !country ||
      !bloodgroup ||
      !emergencyname ||
      !tshirt
    ) {
      Alert.alert("Error", "Please fill in all fields.");
      return;
    }

    // Validate email format
    if (!/\S+@\S+\.\S+/.test(email)) {
      Alert.alert("Error", "Please enter a valid email address.");
      return;
    }

    //Validate emergency number
    if (emergencynumber.length < 10 || isNaN(emergencynumber)) {
      Alert.alert("Error", "Please enter a valid phone number.");
      return;
    }

    //Validate whatsapp number
    if (whatsapp.length < 10 || isNaN(whatsapp)) {
      Alert.alert("Error", "Please enter a valid whatsapp number.");
      return;
    }

    // Validate phone number (example: check length)
    if (phone.length < 10 || isNaN(phone)) {
      Alert.alert("Error", "Please enter a valid phone number.");
      return;
    }

    // Validate passwords match
    if (password !== confirmPassword) {
      Alert.alert("Error", "Passwords do not match.");
      return;
    }
    setLoader(true);
    try {
      const auth = btoa("main_admin:Ze5L lZ7I aOeb kmIc jD3c DZB9"); // Replace with your admin username and application password
      await axios.post(
        `https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/users`,
        {
          first_name: formData.firstname,
          last_name: formData.lastname,
          username: formData.username,
          email: formData.email,
          password: formData.password,
          acf: {
            field_6763b99ffec4d: formData.address,
            field_6763b91bfec4b: formData.gender,
            field_6763b9aefec4e: formData.city,
            field_6763b9b7fec4f: formData.state,
            field_6763b9cefec51: formData.country,
            field_6763b9c2fec50: formData.pin_code,
            field_6763ba5ffec52: formData.bloodgroup,
            field_6763baebfec53: formData.emergencyname,
            field_6763baf9fec54: formData.emergencynumber,
            field_6763c144d8d8a: formData.phone,
            field_6763c155d8d8b: formData.whatsapp,
            field_6763bb0bfec55: formData.tshirt,
          },
        },
        {
          headers: {
            Authorization: `Basic ${auth}`,
          },
        }
      );
      setLoader(false);
      navigation.navigate("Login");
    } catch (error) {
      setLoader(false);
      console.log(error);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value,
    }));
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#fff" }}>
      <View style={[ThemeStyle.mainWrapper, { flex: 1, alignItems: "center" }]}>
        <StatusBar backgroundColor="#fff" barStyle="dark-content" />
        <ScrollView>
          <View
            style={[ThemeStyle.mainWrapper, { flex: 1, alignItems: "center" }]}
          >
            <View>
              <Image
                source={require("../../assets/main-logo.png")}
                style={ThemeStyle.mainLogo}
              />
            </View>

            <View>
              <Text style={ThemeStyle.loginHeader}>Create an account !</Text>
              <Text style={ThemeStyle.loginSubHdng}>
                Please fill the following details to create an account
              </Text>
            </View>

            {/* Firstname */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/user.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter firstname"
                placeholderTextColor="#d3d0d1"
                value={formData.firstname}
                onChangeText={(text) => handleInputChange("firstname", text)}
              />
            </View>

            {/* Lastname */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/user.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter lastname"
                placeholderTextColor="#d3d0d1"
                value={formData.lastname}
                onChangeText={(text) => handleInputChange("lastname", text)}
              />
            </View>

            {/* Username */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/user.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter username"
                placeholderTextColor="#d3d0d1"
                value={formData.username}
                onChangeText={(text) => handleInputChange("username", text)}
              />
            </View>

            {/* Email */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/email.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter email"
                placeholderTextColor="#d3d0d1"
                value={formData.email}
                onChangeText={(text) => handleInputChange("email", text)}
              />
            </View>

            {/* Phone */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/phone.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter phone number"
                placeholderTextColor="#d3d0d1"
                value={formData.phone}
                onChangeText={(text) => handleInputChange("phone", text)}
                keyboardType="phone-pad"
              />
            </View>

            {/* Password */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/pass.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter your password"
                placeholderTextColor="#d3d0d1"
                value={formData.password}
                onChangeText={(text) => handleInputChange("password", text)}
                secureTextEntry
              />
            </View>

            {/* Confirm Password */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/pass.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Confirm password"
                placeholderTextColor="#d3d0d1"
                value={formData.confirmPassword}
                onChangeText={(text) =>
                  handleInputChange("confirmPassword", text)
                }
                secureTextEntry
              />
            </View>

            {/* Address */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/Address.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter address"
                placeholderTextColor="#d3d0d1"
                value={formData.address}
                onChangeText={(text) => handleInputChange("address", text)}
              />
            </View>

            {/* Gender */}
            <View style={ThemeStyle.inputWrap}>
              <Picker
                selectedValue={formData.gender}
                onValueChange={(value) => handleInputChange("gender", value)}
                style={ThemeStyle.globalInput}
              >
                <Picker.Item label="Select Gender" value="" />
                <Picker.Item label="MALE" value="MALE" />
                <Picker.Item label="FEMALE" value="FEMALE" />
                <Picker.Item label="OTHER" value="OTHER" />
              </Picker>
            </View>

            {/* City */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/City.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter city"
                placeholderTextColor="#d3d0d1"
                value={formData.city}
                onChangeText={(text) => handleInputChange("city", text)}
              />
            </View>

            {/* State */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/State.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter state"
                placeholderTextColor="#d3d0d1"
                value={formData.state}
                onChangeText={(text) => handleInputChange("state", text)}
              />
            </View>

            {/* PostelCode */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/PostalCode.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter pincode"
                placeholderTextColor="#d3d0d1"
                value={formData.pin_code}
                onChangeText={(text) => handleInputChange("pin_code", text)}
              />
            </View>

            {/* Country */}
            <View style={ThemeStyle.inputWrap}>
              <Picker
                selectedValue={formData.country}
                onValueChange={(value) => handleInputChange("country", value)}
                style={ThemeStyle.globalInput}
              >
                <Picker.Item label="Select Country" value="" />
                <Picker.Item label="India" value="IN" />
                <Picker.Item label="United States" value="US" />
                <Picker.Item label="Japan" value="JP" />
                <Picker.Item label="Australia" value="AU" />
                <Picker.Item label="Canada" value="CA" />
              </Picker>
            </View>

            {/* BloodGroup */}
            <View style={ThemeStyle.inputWrap}>
              <Picker
                selectedValue={formData.bloodgroup}
                onValueChange={(value) =>
                  handleInputChange("bloodgroup", value)
                }
                style={ThemeStyle.globalInput}
              >
                <Picker.Item label="Select your Blood Group" value="" />
                <Picker.Item label="A+" value="A+" />
                <Picker.Item label="A-" value="A-" />
                <Picker.Item label="B+" value="B+" />
                <Picker.Item label="B-" value="B-" />
                <Picker.Item label="AB+" value="AB+" />
                <Picker.Item label="AB-" value="AB-" />
                <Picker.Item label="O+" value="O+" />
                <Picker.Item label="O-" value="O-" />
              </Picker>
            </View>

            {/* EmergencyName */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/EmergencyName.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter emergencyname"
                placeholderTextColor="#d3d0d1"
                value={formData.emergencyname}
                onChangeText={(text) =>
                  handleInputChange("emergencyname", text)
                }
              />
            </View>

            {/* EmergencyNumber */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/EmergencyNumber.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter emergency number"
                placeholderTextColor="#d3d0d1"
                value={formData.emergencynumber}
                onChangeText={(text) =>
                  handleInputChange("emergencynumber", text)
                }
                keyboardType="phone-pad"
              />
            </View>

            {/* Whatsapp */}
            <View style={ThemeStyle.inputWrap}>
              <Image
                source={require("../../assets/WhatsappNumber.png")}
                style={ThemeStyle.fieldIcon}
              />
              <TextInput
                style={ThemeStyle.globalInput}
                placeholder="Enter whatsapp number"
                placeholderTextColor="#d3d0d1"
                value={formData.whatsapp}
                onChangeText={(text) => handleInputChange("whatsapp", text)}
                keyboardType="phone-pad"
              />
            </View>

            {/* tshirt */}
            <View style={ThemeStyle.inputWrap}>
              <Picker
                selectedValue={formData.tshirt}
                onValueChange={(value) => handleInputChange("tshirt", value)}
                style={ThemeStyle.globalInput}
              >
                <Picker.Item label="Select your T-Shirt" value="" />
                <Picker.Item label="XS" value="XS" />
                <Picker.Item label="S" value="S" />
                <Picker.Item label="M" value="M" />
                <Picker.Item label="L" value="L" />
                <Picker.Item label="XL" value="XL" />
                <Picker.Item label="XXL" value="XXL" />
                <Picker.Item label="XXXL" value="XXXL" />
              </Picker>
            </View>

            {/* Signup */}
            <View style={ThemeStyle.inputWrap}>
              <ImageBackground
                source={require("../../assets/button.png")} // Adjust the path to your image
                style={ThemeStyle.submitBtnBG}
              >
                <TouchableOpacity
                  onPress={handleSubmit}
                  style={ThemeStyle.submitBtn}
                >
                  <Text style={ThemeStyle.submitBtnText}>Signup</Text>
                </TouchableOpacity>
              </ImageBackground>
            </View>

            <View style={ThemeStyle.loginUnderWrap}>
              <Text style={ThemeStyle.loginUnderText}>
                Already have an account ?
              </Text>
              <TouchableOpacity
                onPress={() => navigation.navigate("Login")}
                style={ThemeStyle.loginUnderTouchableArea}
              >
                <Text style={ThemeStyle.signupUnderLogin}> Log in here</Text>
              </TouchableOpacity>
            </View>
            {loader && (
              <View style={ThemeStyle.loaderScreen}>
                <ActivityIndicator size="large" color="#ffffff" />
              </View>
            )}
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export default RegisterScreen;
