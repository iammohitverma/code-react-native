import { vw, vh, vmin, vmax } from "react-native-expo-viewport-units";
import { StyleSheet } from "react-native";

const ThemeStyle = StyleSheet.create({
  // aditya css
  mainWrapper: {
    paddingVertical: 30,
    paddingHorizontal: 15,
    backgroundColor: "#fff",
    width: "100vw",
  },
  mainLogo: {
    width: 200,
    objectFit: "contain",
  },
  loginHeader: {
    fontSize: 32,
    marginTop: 30,
    fontWeight: 500,
    textAlign: "center",
    fontFamily: "Belleza-Regular",
  },
  loginSubHdng: {
    fontSize: 14,
    marginBottom: 25,
    marginTop: 10,
    textAlign: "center",
    color: "#8b8688",
    fontFamily: "DMSans-SemiBold",
    minWidth: "100%",
  },
  inputWrap: {
    width: "100%",
    borderStyle: "solid",
    paddingHorizontal: 30,
    position: "relative",
    marginBottom: 10,
  },
  fieldIcon: {
    position: "absolute",
    left: 45,
    top: 15,
    width: 25,
    height: 25,
  },
  globalInput: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#dedcdd",
    borderStyle: "solid",
    marginBottom: 10,
    height: 50,
    padding: 15,
    paddingLeft: 50,
    fontSize: 14,
    borderRadius: 10,
  },
  submitBtnBG: {
    borderRadius: 10,
    overflow: "hidden",
  },
  submitBtn: {
    color: "#fff",
    paddingVertical: 18,
    paddingHorizontal: 25,
  },
  submitBtnText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: 500,
    fontSize: 16,
  },
  loginUnderWrap: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 10,
  },
  loginUnderText: {
    fontSize: 16,
    fontWeight: 500,
  },
  signupUnderLogin: {
    color: "#2f861b",
    fontSize: 16,
    fontWeight: 500,
  },
  forgotPassword: {
    marginTop: -10,
    marginBottom: 15,
  },
  forgotPasswordText: {
    textAlign: "right",
    fontWeight: 500,
  },
  loaderScreen: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.5)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    paddingBottom: 100,
  },
  ErrorMsg: {
    width: "100%",
    backgroundColor: "#f8d7da",
    paddingHorizontal: 15,
    paddingVertical: 8,
    position: "relative",
    borderWidth: 1,
    borderRadius: 6,
    borderColor: "#f5c6cb",
    color: "#721c24",
    fontSize: 13,
    fontFamily: "DMSans-SemiBold",
  },
  SuccessMsg: {
    width: "100%",
    backgroundColor: "#d4edda",
    paddingHorizontal: 15,
    paddingVertical: 8,
    position: "relative",
    borderWidth: 1,
    borderRadius: 6,
    borderColor: "#c3e6cb",
    color: "#155724",
    fontSize: 13,
    fontFamily: "DMSans-SemiBold",
  },
  ContactScreenBanner: {
    width: "100%",
  },
  // mohit css
  splashBackground: {
    width: "100%",
    height: "100%",
  },
  tinyLogo: {
    width: "100%",
    height: 400,
  },
  WelcomeScreenWrapper: {
    flex: 1,
  },
  WelcomeScreenBanner: {
    width: vw(100),
    height: vh(50),
    minHeight: 300,
  },
  WelcomeScreenTextWrap: {
    paddingHorizontal: 40,
    paddingVertical: 45,
    textAlign: "center",
  },
  WelcomeScreenHeading: {
    fontSize: 32,
    marginBottom: 20,
    color: "#25131A",
    textAlign: "center",
    fontFamily: "Belleza-Regular",
    lineHeight: 40,
  },
  Colored: {
    color: "#0D65DB",
  },
  WelcomeScreenSubHdng: {
    fontSize: 14,
    color: "#8B8688",
    textAlign: "center",
    fontFamily: "DMSans-Medium",
    marginBottom: 40,
    lineHeight: 18,
  },
  GradientButton: {
    paddingHorizontal: 20,
    paddingVertical: 20,
    textAlign: "center",
    fontSize: 16,
    fontWeight: 500,
    color: "#fff",
    fontFamily: "DMSans-SemiBold",
  },
  w_300: {
    width: 300,
  },
  br_10: {
    borderRadius: 10,
    overflow: "hidden",
  },
  br_15: {
    borderRadius: 15,
    overflow: "hidden",
  },
  logoOverlay: {
    flex: 1,
    position: "absolute",
    width: "100%",
    height: "100%",
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1,
    overflow: "hidden",
  },
  HeaderWrap: {
    width: "100%",
    backgroundColor: "#fff",
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerInner: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  HeaderIcons: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  categoryIconsWrapper: {
    paddingVertical: 20,
  },
  categoryIconBox: {
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 15,
  },
  fs_12_600: {
    fontSize: 14,
    fontFamily: "DMSans-Bold",
    color: "#222222",
  },
  fs_12_400: {
    fontSize: 12,
    fontFamily: "DMSans-Regular",
    color: "#222222",
  },
  fs_16_500: {
    fontSize: 16,
    fontFamily: "DMSans-Medium",
    color: "#120D26",
  },
  fs_15_400: {
    fontSize: 15,
    fontFamily: "DMSans-Regular",
    color: "#807A7A",
  },
  mb_10: {
    marginBottom: 10,
  },
  mb_20: {
    marginBottom: 20,
  },
  pt_10: {
    paddingTop: 10,
  },
  pb_10: {
    paddingBottom: 10,
  },
  pt_20: {
    paddingTop: 20,
  },
  pb_20: {
    paddingBottom: 20,
  },
  py_20: {
    paddingVertical: 20,
  },
  px_20: {
    paddingHorizontal: 20,
  },
  pt_30: {
    paddingTop: 30,
  },
  pb_30: {
    paddingBottom: 30,
  },
  py_30: {
    paddingVertical: 30,
  },
  px_30: {
    paddingHorizontal: 30,
  },
  categoryBtn: {
    overflow: "hidden",
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#8B8688",
    marginHorizontal: 10,
  },
  categoryBtnInner: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    paddingHorizontal: 15,
  },
  eventsListingWrapper: {
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  eventListingCard: {
    padding: 15,
    borderRadius: 20,
    backgroundColor: "#fff",
    elevation: 2,
    marginBottom: 15,
  },
  eventListingCardInner: {
    flexDirection: "row",
  },
  eventListingCardDetail: {
    flexShrink: 1,
  },
  eventTime: {
    fontSize: 13,
    color: "#2F861B",
    marginBottom: 7,
    fontFamily: "DMSans-Regular",
  },
  eventTitle: {
    fontSize: 17,
    color: "#120D26",
    marginBottom: 7,
    fontFamily: "DMSans-Medium",
  },
  eventLocationWrap: {
    flexDirection: "row",
    alignItems: "center",
  },
  eventLocation: {
    fontSize: 13,
    color: "#807A7A",
    fontFamily: "DMSans-Regular",
  },
  ProfileScreenHeader: {
    padding: 20,
    marginBottom: 10,
  },
  ProfileScreenName: {
    fontSize: 22,
    color: "#000000",
    fontFamily: "DMSans-Bold",
    marginTop: 10,
  },
  ProfileScreenMenuWrap: {
    paddingHorizontal: 20,
  },
  ProfileScreenMenuBtn: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  ProfileScreenMenuText: {
    fontSize: 16,
    color: "#000000",
    fontFamily: "DMSans-Regular",
  },
  BellezaFont: {
    fontFamily: "Belleza-Regular",
  },
  EventScreenBanner: {
    paddingHorizontal: 20,
    paddingVertical: 50,
  },
  BlogListingCard: {
    backgroundColor: "#fff",
    marginHorizontal: 15,
    padding: 15,
    marginBottom: 20,
    elevation: 2,
    borderRadius: 3,
  },
  blogTitle: {
    fontSize: 18,
    color: "#000000",
    marginBottom: 7,
    fontFamily: "DMSans-SemiBold",
  },
  publishTime: {
    fontSize: 14,
    color: "#8a8a8a",
    fontFamily: "DMSans-Regular",
  },
  blogAuthorWrap: {
    flexDirection: "row",
    marginTop: 7,
  },
  blogAuthor: {
    fontSize: 13,
    color: "#bdbdbd",
    fontFamily: "DMSans-Regular",
  },
  grey: {
    color: "#807A7A",
  },
  white: {
    color: "#ffffff",
  },
  DMSans900: {
    fontFamily: "DMSans-Black",
  },
  DMSans700: {
    fontFamily: "DMSans-Bold",
  },
  DMSans800: {
    fontFamily: "DMSans-ExtraBold",
  },
  DMSans200: {
    fontFamily: "DMSans-ExtraLight",
  },
  DMSans300: {
    fontFamily: "DMSans-Light",
  },
  DMSans500: {
    fontFamily: "DMSans-Medium",
  },
  DMSans400: {
    fontFamily: "DMSans-Regular",
  },
  DMSans600: {
    fontFamily: "DMSans-SemiBold",
  },
  DMSans100: {
    fontFamily: "DMSans-Thin",
  },
});

export default ThemeStyle;
