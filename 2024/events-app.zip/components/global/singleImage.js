import { useState, useEffect } from "react";
import { Image } from "react-native";
import axios from 'axios';
const ImageBox = ({ ImageId }) => {
    const imageId = ImageId;
    const [MediaItem, setMediaItems] = useState(null);
    useEffect(() => {
        const fetchAllMedia = async () => {
            try {
                // Use Promise.all to fetch all media items
                const responses = await axios.get(`https://bookmyevents.tmdemo.in/bme-admin/wp-json/wp/v2/media/${imageId}`);
                if (responses.data.media_details.sizes.thumbnail.source_url) {
                    setMediaItems(responses.data.media_details.sizes.thumbnail.source_url); // Set the image URL
                } else {
                    console.warn("Media not found for banner_bg:");
                }
            } catch (error) {
                setMediaItems('https://bookmyevents.tmdemo.in/bme-admin/wp-content/uploads/2024/12/placeholder.png');
               //console.error("Error fetching data:", error);
            }
        };

        fetchAllMedia();
    }, [imageId]);

    if (MediaItem != null){         
    return (
        <Image
                            style={{
                              height: 100,
                              width: 80,
                              marginRight: 10,
                              borderRadius: 10,
                            }}
                            // source={item.eventFeaturedImage}
                    source={{ uri: MediaItem}}
                            resizeMode="cover"
                          />
       
    );
}
};

export default ImageBox;