import React, { useState } from "react";
import {
  View,
  Text,
  Button,
  Image,
  FlatList,
  ScrollView,
  SectionList,
} from "react-native";

import styles from "./components/CustomStyle";

import ChildComp from "./components/ChildComp";

function App() {
  const name = "Mohit Verma";
  const [age, setAge] = useState(26);
  const number = 2;
  const ageCalc = () => {
    return age + 4;
  };
  const myFun = () => {
    console.warn("Age" + age);
    setAge(18);
  };
  let pic = {
    uri: "https://upload.wikimedia.org/wikipedia/commons/d/de/Bananavarieties.jpg",
  };

  const friendsNames = [
    {
      id: 1,
      name: "Mohit",
    },
    {
      id: 2,
      name: "Rohit",
    },
    {
      id: 3,
      name: "Anshu",
    },
    {
      id: 4,
      name: "Anshu",
    },
    {
      id: 5,
      name: "Anshu",
    },
  ];

  const DATA = [
    {
      title: "Main dishes",
      data: ["Pizza", "Burger", "Risotto"],
    },
    {
      title: "Sides",
      data: ["French Fries", "Onion Rings", "Fried Shrimps"],
    },
    {
      title: "Drinks",
      data: ["Water", "Coke", "Beer"],
    },
    {
      title: "Desserts",
      data: ["Cheese Cake", "Ice Cream"],
    },
  ];

  const [show, setShow] = useState(false);

  return (
    <ScrollView>
      <View>
        {show && <View style={styles.box}></View>}
        <Button onPress={() => setShow(true)}>Toggle</Button>
      </View>
      <View style={[styles.container]}>
        <Text style={{ fontSize: 16 }}>Hello {name}</Text>
        <Text style={[styles.text]}>Your age is {age}</Text>
        <Text>
          {number} * {number} is {number * number}
        </Text>
        <Image
          source={{
            uri: "https://reactnative.dev/img/tiny_logo.png",
          }}
          style={{ width: 110, height: 110, marginTop: 50 }}
        />
        <Image
          source={pic}
          style={{ width: 193, height: 110, marginTop: 50 }}
        />
        <Text>{ageCalc()}</Text>
        <Button title="Read More" onPress={myFun} />
        <ChildComp name={name} />

        <FlatList
          data={friendsNames}
          renderItem={({ item }) => {
            return (
              <Text
                style={{
                  padding: 10,
                  backgroundColor: "#111",
                  color: "#fff",
                  marginBottom: 15,
                }}
              >
                {item.name}
              </Text>
            );
          }}
          keyExtractor={(key) => {
            return key.id;
          }}
        />

        <View style={{ flex: 1, flexDirection: "row", flexWrap: "wrap" }}>
          {friendsNames.map((item) => {
            return (
              <Text key={item.id} style={styles.box}>
                {item.id}
              </Text>
            );
          })}
        </View>

        <View style={{ flex: 1, flexDirection: "row" }}>
          <SectionList
            sections={DATA}
            keyExtractor={(item, index) => item + index}
            renderItem={({ item }) => (
              <View style={styles.box}>
                <Text style={styles.title}>{item}</Text>
              </View>
            )}
            renderSectionHeader={({ section: { title } }) => (
              <Text style={styles.header}>{title}</Text>
            )}
          />
        </View>
      </View>
    </ScrollView>
  );
}

export default App;
