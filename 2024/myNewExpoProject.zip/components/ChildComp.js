import { useState } from "react";
import { View, Text, TextInput } from "react-native";
import styles from "./CustomStyle";

// function ChildComp({ name }) {
//   const [inputValue, setVal] = useState("");
//   return (
//     <View style={{ marginTop: 50 }}>
//       <Text>Hello Child Component</Text>
//       <Text>Your Value is {inputValue} </Text>
//       <TextInput
//         style={styles.textInput}
//         placeholder={name}
//         value={inputValue}
//         onChangeText={(e) => setVal(e)}
//       />
//     </View>
//   );
// }
// export default ChildComp;

export default ChildComp = ({ name }) => {
  const [inputValue, setVal] = useState("");
  return (
    <View style={{ marginTop: 50 }}>
      <Text>Hello Child Component</Text>
      <Text>Your Value is {inputValue} </Text>
      <TextInput
        style={styles.textInput}
        placeholder={name}
        value={inputValue}
        onChangeText={(e) => setVal(e)}
      />
    </View>
  );
};
