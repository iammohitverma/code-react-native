import { StyleSheet } from "react-native";

const CustomStyle = StyleSheet.create({
  container: {
    padding: 30,
    flex: 1,
    justifyContent: "center",
  },
  text: {
    color: "#e94c88",
    fontSize: 16,
  },
  textInput: {
    padding: 10,
    borderColor: "#dfe6e9",
    borderWidth: 1,
  },
  box: {
    flex: 1,
    padding: 15,
    width: 100,
    height: 100,
    textAlign: "center",
    textAlignVertical: "center",
    backgroundColor: "#fff",
    borderWidth: 2,
    borderColor: "#111",
  },
});

export default CustomStyle;
