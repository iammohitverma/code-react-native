import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import HomeScreen from "./Components/Home";
import AboutScreen from "./Components/About";
import ApiDataScreen from "./Components/ApiData";
import PostApiDataScreen from "./Components/PostApiData";
import UseRefHookScreen from "./Components/UseRefHook";
import AsyncStorageScreen from "./Components/AsyncStorage";
import LiveApiDataScreen from "./Components/LiveApiDataScreen";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";

const App = () => {
  const Drawer = createDrawerNavigator();

  return (
    <NavigationContainer>
      <Drawer.Navigator
        initialRouteName="Home"
        drawerPosition="right"
        drawerType="front"
        edgeWidth={100}
        hideStatusBar={false}
        overlayColor="#000"
        drawerStyle={{
          backgroundColor: "#fff",
          width: 200,
        }}
        screenOptions={{
          headerShown: true,
          swipeEnabled: true,
          gestureEnabled: true,
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#fff" },
          headerTitleStyle: { fontSize: 25 },
        }}
      >
        <Drawer.Screen
          name="Home"
          component={HomeScreen}
          options={{
            title: "My Home",
          }}
        />
        <Drawer.Screen
          name="About"
          component={AboutScreen}
          options={{
            title: "My About",
            drawerIcon: ({ focused }) => (
              <FontAwesome5
                name="info-circle"
                size={focused ? 25 : 20}
                color={focused ? "skyblue" : "#000"}
              />
            ),
          }}
        />
        <Drawer.Screen
          name="ApiData"
          component={ApiDataScreen}
          options={{
            title: "API Data",
          }}
        />
        <Drawer.Screen
          name="PostApiDataScreen"
          component={PostApiDataScreen}
          options={{
            title: "Post API Data",
          }}
        />
        <Drawer.Screen
          name="UseRefHookScreen"
          component={UseRefHookScreen}
          options={{
            title: "useRef Hook",
          }}
        />
        <Drawer.Screen
          name="AsyncStorageScreen"
          component={AsyncStorageScreen}
          options={{
            title: "Async Storage",
          }}
        />
        <Drawer.Screen
          name="LiveApiData"
          component={LiveApiDataScreen}
          options={{
            title: "Live API Data",
          }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
};

export default App;
