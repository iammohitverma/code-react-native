import {
  View,
  Text,
  StatusBar,
  FlatList,
  TouchableOpacity,
} from "react-native";
import styles from "./Css/CustomStyles";
import { useEffect, useState } from "react";

export default function ApiData() {
  // Read db data
  const [apidata, setApidata] = useState([]);
  const url = "http://192.168.100.111:3000/users";
  const getData = async () => {
    try {
      const response = await fetch(url);
      const json = await response.json();
      setApidata(json);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    getData();
  });

  // Delete from db
  const onDelete = async (ID) => {
    try {
      let result = await fetch(`${url}/${ID}`, {
        method: "DELETE",
      });

      if (result.ok) {
        const response = await result.json();
        console.log("Delete response:", response);
        getData();
      } else {
        console.warn("Failed to delete item:", result.status);
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };
  return (
    <View style={styles.container}>
      <StatusBar />
      <Text style={{ marginBottom: 10 }}>ApiData</Text>
      <FlatList
        data={apidata}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.dataBox}>
            <Text style={styles.count}>ID = {item.id}</Text>
            <Text style={styles.label}>{item.name}</Text>
            <View style={{ flexDirection: "row", gap: 10 }}>
              <View style={{ width: "40%", flexGrow: 1 }}>
                <TouchableOpacity onPress={() => onDelete(item.id)}>
                  <Text style={[styles.button, styles.warning]}>Delete</Text>
                </TouchableOpacity>
              </View>
              <View style={{ width: "40%", flexGrow: 1 }}>
                <TouchableOpacity>
                  <Text style={[styles.button, styles.success]}>Edit</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
}
