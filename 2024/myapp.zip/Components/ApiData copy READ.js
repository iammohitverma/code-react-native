import {
  View,
  Text,
  StatusBar,
  FlatList,
  TouchableOpacity,
} from "react-native";
import styles from "./Css/CustomStyles";
import { useEffect, useState } from "react";

export default function ApiData() {
  const [apidata, setApidata] = useState([]);
  // const url = "https://jsonplaceholder.typicode.com/posts/";
  // const url = "https://mocki.io/v1/320f170e-6fcf-4270-b0d9-e58dcda0a090";
  // const url = "http://192.168.100.111:3000/comments";
  const url = "http://192.168.100.111:3000/users";
  const getData = async () => {
    try {
      const response = await fetch(url);
      const json = await response.json();
      setApidata(json);
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    getData();
  });

  const onDelete = () => {
    console.log("Deleted");
  };
  return (
    <View style={styles.container}>
      <StatusBar />
      <Text style={{ marginBottom: 10 }}>ApiDataa</Text>
      <FlatList
        data={apidata}
        renderItem={({ item }) => {
          return (
            <View style={styles.dataBox}>
              <Text style={styles.count}>ID = {item.id}</Text>
              <Text style={styles.label}>{item.name}</Text>
              <View style={{ flexDirection: "row", gap: 10 }}>
                <View style={{ width: "40%", flexGrow: 1 }}>
                  <TouchableOpacity onPress={onDelete}>
                    <Text style={[styles.button, styles.warning]}>Delete</Text>
                  </TouchableOpacity>
                </View>
                <View style={{ width: "40%", flexGrow: 1 }}>
                  <TouchableOpacity onPress={onDelete}>
                    <Text style={[styles.button, styles.success]}>
                      Press Here
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          );
        }}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}
