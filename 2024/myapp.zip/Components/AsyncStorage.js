// command to install async-storage using expo
// npx expo install @react-native-async-storage/async-storage

// Documentation
// https://react-native-async-storage.github.io/async-storage/docs/usage/

import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";
import { Text, View, TextInput, Button } from "react-native";
import styles from "./Css/CustomStyles";

export default function UseRefHookScreen() {
  const [formData, setFormData] = useState({ name: "", email: "" });

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const SaveToStorage = async () => {
    console.log("Saved");
    try {
      const jsonValue = JSON.stringify(formData);
      await AsyncStorage.setItem("form-data", jsonValue);
    } catch (e) {
      // saving error
    }
  };

  const getData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem("form-data");
      if (jsonValue) {
        const parsedData = jsonValue != null ? JSON.parse(jsonValue) : null;
        setFormData(parsedData);
      }
    } catch (e) {
      // error reading value
    }
  };
  useEffect(() => {
    getData();
  }, []);

  return (
    <View style={styles.container}>
      <Text>Hello UseRef Hook</Text>
      <Text>{JSON.stringify(formData)}</Text>
      <View style={styles.inputWrap}>
        <TextInput
          placeholder="Name"
          style={styles.input}
          value={formData.name}
          onChangeText={(text) => handleInputChange("name", text)}
        />
      </View>
      <View style={styles.inputWrap}>
        <TextInput
          placeholder="Email"
          style={styles.input}
          value={formData.email}
          onChangeText={(text) => handleInputChange("email", text)}
        />
      </View>
      <View style={styles.inputWrap}>
        <Button title="Click" onPress={SaveToStorage} />
      </View>
    </View>
  );
}
