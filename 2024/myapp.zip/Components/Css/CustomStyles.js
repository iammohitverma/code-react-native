import { StyleSheet } from "react-native";
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  btnStyle: {
    backgroundColor: "skyblue",
  },
  btnTextStyle: {
    fontSize: 22,
    fontWeight: 600,
    textTransform: "uppercase",
    textAlign: "center",
  },
  inputWrap: {
    marginBottom: 20,
  },
  mb_10: {
    marginBottom: 10,
  },
  mb_20: {
    marginBottom: 20,
  },
  dataBox: {
    backgroundColor: "skyblue",
    padding: 20,
    marginBottom: 20,
    elevation: 7,
    borderRadius: 10,
  },
  count: {
    width: 150,
    textAlign: "center",
    textAlignVertical: "center",
    backgroundColor: "yellow",
    padding: 10,
    margin: "auto",
    marginBottom: 20,
    borderRadius: 10,
  },
  label: {
    backgroundColor: "#fff",
    padding: 10,
    marginBottom: 20,
    borderRadius: 10,
  },
  input: {
    backgroundColor: "#fff",
    padding: 20,
    color: "#000",
    fontSize: 16,
    elevation: 10,
  },
  errorMsg: {
    backgroundColor: "red",
    paddingVertical: 5,
    paddingHorizontal: 10,
    color: "#fff",
    fontSize: 14,
  },
  button: {
    padding: 10,
    fontSize: 16,
    fontWeight: 500,
    textAlign: "center",
  },
  warning: {
    backgroundColor: "red",
    color: "#fff",
  },
  success: {
    backgroundColor: "orange",
    color: "#111",
  },
  centeredView: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
    padding: 20,
  },
  modalView: {
    backgroundColor: "#fff",
    padding: 40,
    elevation: 5,
    width: "100%",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 500,
    marginBottom: 10,
  },
});
export default styles;
