import { useState } from "react";
import { Text, View, TextInput, Button } from "react-native";
import styles from "./Css/CustomStyles";

export default function UseRefHookScreen() {
  const [formData, setFormData] = useState({ name: "", email: "" });

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <View style={styles.container}>
      <Text>Hello UseRef Hook</Text>
      <Text>{JSON.stringify(formData)}</Text>
      <View style={styles.inputWrap}>
        <TextInput
          placeholder="Name"
          style={styles.input}
          value={formData.name}
          onChangeText={(text) => handleInputChange("name", text)}
        />
      </View>
      <View style={styles.inputWrap}>
        <TextInput
          placeholder="Email"
          style={styles.input}
          value={formData.email}
          onChangeText={(text) => handleInputChange("email", text)}
        />
      </View>
      <View style={styles.inputWrap}>
        <Button title="Click" onPress={() => console.log(formData)} />
      </View>
    </View>
  );
}
