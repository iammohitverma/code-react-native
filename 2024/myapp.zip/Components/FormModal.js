import { View, Text, TouchableOpacity, TextInput } from "react-native";
import styles from "./Css/CustomStyles";
import { useState } from "react";

// FormModal Component here
export default function FormModal({ modalTrigger, userData }) {
  const [name, setName] = useState(userData ? userData.name : "");
  const [email, setEmail] = useState(userData ? userData.email : "");
  const [age, setAge] = useState(userData ? userData.age : "");
  const ID = userData.id;

  // Update from db
  const url = "http://192.168.100.111:3000/users";
  const onUpdate = async () => {
    const updatedUserData = {
      name: name,
      email: email,
      age: age,
    };
    try {
      let result = await fetch(`${url}/${ID}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedUserData), // Include the updated data
      });

      if (result.ok) {
        const response = await result.json();
        console.log("Update response:", response);
        modalTrigger();
      } else {
        console.warn("Failed to update item:", result.status);
      }
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };
  return (
    <View style={styles.centeredView}>
      <View style={styles.modalView}>
        <Text style={styles.modalTitle}>Update Data!</Text>
        <Text style={styles.modalTitle}>{JSON.stringify(userData)}</Text>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={name}
            placeholder="Name"
            onChangeText={(e) => setName(e)}
          />
        </View>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={email}
            placeholder="Email"
            onChangeText={(e) => setEmail(e)}
          />
        </View>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={age}
            placeholder="Age"
            onChangeText={(e) => setAge(e)}
          />
        </View>
        <View style={styles.inputWrap}>
          <TouchableOpacity onPress={onUpdate}>
            <Text style={[styles.button, styles.btnStyle]}>Update Now</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={modalTrigger}>
          <Text style={[styles.button, styles.success]}>Hide Modal</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
