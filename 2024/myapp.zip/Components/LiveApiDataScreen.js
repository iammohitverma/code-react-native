import React, { useEffect, useState } from "react";
import { View, Text, StatusBar, FlatList } from "react-native";

export default function LiveApiDataScreen() {
  const placeholderData = Array(10).fill(null); // Placeholder array
  const [loadingState, setLoadingState] = useState(true); // Loading State
  const [apiData, setApiData] = useState([]);
  const url = "https://jsonplaceholder.typicode.com/photos";

  const getData = async () => {
    try {
      const response = await fetch(url);
      const json = await response.json();
      setApiData(json);
      setLoadingState(true); // Loading complete
    } catch (error) {
      console.error(error);
      setLoadingState(true); // Stop loading even on error
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar />
      <Text style={{ marginBottom: 10, fontSize: 18, fontWeight: "bold" }}>
        API Data
      </Text>
      {loadingState ? (
        <FlatList
          data={placeholderData}
          renderItem={({ item, index }) => <PlaceholderCard key={index} />}
          keyExtractor={(item, index) => index.toString()}
        />
      ) : (
        <FlatList
          data={apiData}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.cardText}>{item.title}</Text>
            </View>
          )}
          keyExtractor={(item) => item.id.toString()}
        />
      )}
    </View>
  );
}

export function PlaceholderCard() {
  return (
    <View style={styles.placeholderCard}>
      <Text style={styles.placeholderText}>Loading...</Text>
    </View>
  );
}

// Add to CustomStyles or inline styles
const styles = {
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#fff",
  },
  card: {
    marginBottom: 10,
    backgroundColor: "crimson",
    padding: 20,
    borderRadius: 8,
  },
  cardText: {
    color: "white",
    fontSize: 16,
  },
  placeholderCard: {
    marginBottom: 10,
    backgroundColor: "lightgray",
    padding: 20,
    borderRadius: 8,
  },
  placeholderText: {
    color: "darkgray",
    fontSize: 16,
  },
};
