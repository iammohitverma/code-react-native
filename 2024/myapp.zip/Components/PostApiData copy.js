import { Text, View, Button } from "react-native";
import styles from "./Css/CustomStyles";

export default function PostApiData() {
  const url = "http://192.168.100.111:3000/comments";
  const saveAPIData = async () => {
    console.log("Run");
    const data = {
      body: "Great post!",
    };
    try {
      let result = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      result = await result.json();
      console.warn(result);
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };

  return (
    <View style={styles.container}>
      <Text>Hello I am PostApiData</Text>
      <View>
        <Button title="Click me" onPress={saveAPIData} />
      </View>
    </View>
  );
}
