import { Text, View, Button, TextInput, ScrollView } from "react-native";
import styles from "./Css/CustomStyles";
import { useState } from "react";

export default function PostApiData() {
  const [nameValue, handleName] = useState("");
  const [emailValue, handleEmail] = useState("");
  const [ageValue, handleAge] = useState("");

  const [nameError, handleNameError] = useState(false);
  const [emailError, handleEmailError] = useState(false);
  const [ageError, handleAgeError] = useState(false);

  const sendData = () => {
    if (!nameValue) {
      handleNameError(true);
    } else {
      handleNameError(false);
    }
    if (!emailValue) {
      handleEmailError(true);
    } else {
      handleEmailError(false);
    }
    if (!ageValue) {
      handleAgeError(true);
    } else {
      handleAgeError(false);
    }
    if (nameValue && ageValue && ageValue) {
      saveAPIData();
      handleName("");
      handleEmail("");
      handleAge("");
    }
  };

  const saveAPIData = async () => {
    const url = "http://192.168.100.111:3000/users";
    const data = {
      name: nameValue,
      email: emailValue,
      age: ageValue,
    };
    try {
      let result = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      result = await result.json();
      console.warn(result);
    } catch (error) {
      console.error("Error sending data:", error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.mb_10}>PostApiData</Text>
      <ScrollView>
        <Text style={styles.mb_10}>Name: {nameValue}</Text>
        <Text style={styles.mb_10}>Email: {emailValue}</Text>
        <Text style={styles.mb_10}>Age: {ageValue}</Text>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={nameValue}
            placeholder="Name"
            onChangeText={(e) => handleName(e)}
          />
          {nameError && <Text style={styles.errorMsg}>Please enter name</Text>}
        </View>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={emailValue}
            placeholder="Email"
            onChangeText={(e) => handleEmail(e)}
          />
          {emailError && (
            <Text style={styles.errorMsg}>Please enter email</Text>
          )}
        </View>
        <View style={styles.inputWrap}>
          <TextInput
            style={styles.input}
            value={ageValue}
            placeholder="Age"
            onChangeText={(e) => handleAge(e)}
          />
          {ageError && <Text style={styles.errorMsg}>Please enter age</Text>}
        </View>
        <View style={styles.inputWrap}>
          <Button title="Click me" onPress={sendData} />
        </View>
      </ScrollView>
    </View>
  );
}
