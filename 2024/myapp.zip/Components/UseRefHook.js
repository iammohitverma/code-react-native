import { useRef } from "react";
import { Text, View, TextInput, Button } from "react-native";
import styles from "./Css/CustomStyles";

export default function UseRefHookScreen() {
  const inputRef = useRef(null);
  const getData = () => {
    console.log(inputRef);
    inputRef.current.focus();
  };
  return (
    <View style={styles.container}>
      <Text>Hello UseRef Hook</Text>
      <View style={styles.inputWrap}>
        <TextInput placeholder="Name" style={styles.input} ref={inputRef} />
      </View>
      <View style={styles.inputWrap}>
        <TextInput placeholder="Email" style={styles.input} />
      </View>
      <View style={styles.inputWrap}>
        <Button title="Click" onPress={getData} />
      </View>
    </View>
  );
}
