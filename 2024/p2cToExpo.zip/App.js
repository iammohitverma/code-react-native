import React from "react";
import MainScreen from "./component/MainScreen";
import LoginScreen from "./component/LoginScreen";
import RegisterScreen from "./component/RegisterScreen";
import PickUpLocationScreen from "./component/PickUpLocationScreen";
import ForgotPasswordScreen from "./component/ForgotPasswordScreen";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import ProfileScreen from "./component/ProfileScreen";
import MainProfileScreen from "./component/MainProfileScreen";
import ContactScreen from "./component/ContactScreen";
import PaymentMethodScreen from "./component/PaymentMethodScreen";
import EditCardScreen from "./component/EditCardScreen";
import AddCardScreen from "./component/AddCardScreen";
import EditBankScreen from "./component/EditBankScreen";
import AddBankScreen from "./component/AddBankScreen";
import WelcomeScreen from "./component/WelcomeScreen";
import Popup from "./component/Popup";
import FormUpdatePopUp from "./component/FormUpdatePopUp";
import SendMoneyScreen from "./component/SendMoneyScreen";
import HomeScreen from "./component/HomeScreen";
import AllScreenList from "./component/AllScreenList";
import GenerateReportScreen from "./component/GenerateReportScreen";
import FaqScreen from "./component/FaqScreen";
import SplashScreen from "./component/SplashScreen";

const Stack = createNativeStackNavigator();
const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: "#ffffff",
  },
};
function App() {
  return (
    <NavigationContainer theme={MyTheme}>
      <Stack.Navigator initialRouteName="SplashAnimate">
        <Stack.Screen
          name="SplashAnimate"
          component={SplashScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Main"
          component={MainScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Register"
          component={RegisterScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="PickUpLocation"
          component={PickUpLocationScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ForgotPassword"
          component={ForgotPasswordScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Profile"
          component={ProfileScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="MainProfile"
          component={MainProfileScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Contact"
          component={ContactScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="PaymentMethod"
          component={PaymentMethodScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="EditCard"
          component={EditCardScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="AddCard"
          component={AddCardScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="EditBank"
          component={EditBankScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="AddBank"
          component={AddBankScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="WelcomePage"
          component={WelcomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Popup"
          component={Popup}
          options={{ headerShown: true }}
        />
        <Stack.Screen
          name="SendMoney"
          component={SendMoneyScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="GenerateReport"
          component={GenerateReportScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="FaqScreen"
          component={FaqScreen}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="FormUpdatePopUp"
          component={FormUpdatePopUp}
          options={{ headerShown: true }}
        />
        <Stack.Screen
          name="AllScreenList"
          component={AllScreenList}
          options={{ headerShown: true }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
