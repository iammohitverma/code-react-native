import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const AddCardScreen = ({navigation}) => {
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Payment Method
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>
                
                <View style={ThemeStyle.pmSecHdr}>
                    <View style={ThemeStyle.pmSecBoxRight}>
                        <Image
                            style={ThemeStyle.pmIconAdd}
                            source={require('../assets/add_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconSubdng}>
                            Add New Cards
                        </Text>
                    </View>
                </View>

                
                <View style={ThemeStyle.EditCardForm}>
                    <View>
                        <Text style={ThemeStyle.LoginLabel}>Name on Card*</Text>
                        <TextInput 
                        placeholder='Master Card'  
                        style={ThemeStyle.LoginInpt}> 
                        </TextInput>
                    </View>
                    <View>
                        <Text style={ThemeStyle.LoginLabel}>Card Number*</Text>
                        <TextInput 
                        placeholder='*****'  
                        style={ThemeStyle.LoginInpt}> 
                        </TextInput>
                    </View>
                    <View>
                        <Text style={ThemeStyle.LoginLabel}>Confirm Card Number*</Text>
                        <TextInput 
                        placeholder='*****'  
                        style={ThemeStyle.LoginInpt}> 
                        </TextInput>
                    </View>
                    <View style={ThemeStyle.LoginFormBoxRow}>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Expiration Date*</Text>
                            <TextInput 
                            placeholder='12/26'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Security Code*</Text>
                            <TextInput 
                            placeholder='000'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>
                    </View>

                    <View>
                        <Pressable>
                            <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                <Text style={ThemeStyle.GradientBtnText}>Submit</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default AddCardScreen;
