import React from 'react';
import {
    Text,
    View,
    Button,
    StyleSheet,
    Image,
    Pressable,
    SafeAreaView, 
    ScrollView,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const AllScreenList = ({navigation}) => {
    return(
        <SafeAreaView style={ThemeStyle.container}>
            <ScrollView>
                <View>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('Home')}>Home</Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('Profile')}> Profile</Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('MainProfile')}> Main Profile</Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('Contact')}> Contact </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('ForgotPassword')}>Forgot Password?</Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('Register')}> REGISTER NOW</Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('PaymentMethod')}> Payment Method </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('EditCard')}> Edit Card </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('AddCard')}> Add Card </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('EditBank')}> Edit Bank </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('AddBank')}> Add Bank </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('WelcomePage')}> Welcome Screen </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('Popup')}> Popup </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('FormUpdatePopUp')}> Form Update Popup </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('SendMoney')}> Send Money Screen </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('GenerateReport')}> Generate Report </Text>
                    <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('FaqScreen')}> FAQ </Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default AllScreenList;
