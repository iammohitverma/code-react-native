import React, { useState } from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';
import { CheckBox } from 'react-native-elements';


const ContactScreen = ({navigation}) => {
    const [check1, setCheck1] = useState(false);
    const [check2, setCheck2] = useState(false);
    const [check3, setCheck3] = useState(false);
    const [check4, setCheck4] = useState(false);
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Contact
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>

                <View style={ThemeStyle.ContactWrap}>
                    <Text style={ThemeStyle.cntctSubText}>
                        Have a Question? Have Problem? Want More Information?
                    </Text>
                    <Text style={ThemeStyle.cntctMainText}>
                        Give us a little information and we’ll get in touch within one business day.
                    </Text>

                    {/* Contact Form Fields */}

                    <View style={ThemeStyle.ContactFormBoxRow}>
                        <Text style={ThemeStyle.ContactLabel}>Your Name</Text>

                        <TextInput 
                        placeholder='First Bank of Boston'  
                        style={ThemeStyle.ContactInpt}> 
                        </TextInput>
                    </View>

                    <View style={ThemeStyle.ContactFormBoxRow}>
                        <Text style={ThemeStyle.ContactLabel}>Your Company</Text>

                        <TextInput 
                        placeholder='**** **** ****'  
                        style={ThemeStyle.ContactInpt}> 
                        </TextInput>
                    </View>

                    <View style={ThemeStyle.ContactFormBoxRow}>
                        <Text style={ThemeStyle.ContactLabel}>Your Email</Text>

                        <TextInput 
                        placeholder='**** **** ****'  
                        style={ThemeStyle.ContactInpt}> 
                        </TextInput>
                    </View>

                    <View style={ThemeStyle.ContactFormBoxRow,ThemeStyle.LoginFormBoxRow}>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.ContactLabel}>Your Phone</Text>
                            <TextInput 
                            placeholder='Phone'  
                            style={ThemeStyle.ContactInpt}> 
                            </TextInput>
                        </View>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.ContactLabel}>Extension</Text>
                            <TextInput 
                            placeholder='Extension'  
                            style={ThemeStyle.ContactInpt}> 
                            </TextInput>
                        </View>
                    </View>

                    <View style={ThemeStyle.ContactFormBoxRow}>
                        <View style={ThemeStyle.ContactCheckBoxes}>
                            <CheckBox
                                size={18}
                                checkedColor="#272728"
                                checked={ check1 }
                                onPress={() => setCheck1(!check1)}
                            />
                            <Text style={ThemeStyle.RadioText}>
                                General Question or Comment
                            </Text>
                        </View>
                        <View style={ThemeStyle.ContactCheckBoxes}>
                            <CheckBox
                                size={18}
                                checkedColor="#272728"
                                checked={ check2 }
                                onPress={() => setCheck2(!check2)}
                            />
                            <Text style={ThemeStyle.RadioText}>
                                Complaint
                            </Text>
                        </View>
                        <View style={ThemeStyle.ContactCheckBoxes}>
                            <CheckBox
                                size={18}
                                checkedColor="#272728"
                                checked={ check3 }
                                onPress={() => setCheck3(!check3)}
                            />
                            <Text style={ThemeStyle.RadioText}>
                                Report Fraud
                            </Text>
                        </View>
                        <View style={[ThemeStyle.ContactCheckBoxes,{marginBottom:0}]}>
                            <CheckBox
                                size={18}
                                checkedColor="#272728"
                                checked={ check4 }
                                onPress={() => setCheck4(!check4)}
                            />
                            <Text style={ThemeStyle.RadioText}>
                                I Am A Pin2Cash Agent On Behalf Of a Client
                            </Text>
                        </View>
                    </View>

                    <View style={ThemeStyle.ContactFormBoxRow}>

                        <TextInput 
                        placeholder='Message'  
                        multiline = {true}
                        numberOfLines = {7}
                        style={ThemeStyle.ContactTA}> 
                        </TextInput>
                    </View>

                    <Pressable>
                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={[ThemeStyle.GradientBtnBox,ThemeStyle.mb_20]}>
                            <Text style={ThemeStyle.GradientBtnText}>Submit</Text>
                        </ImageBackground>
                    </Pressable>
                    

                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default ContactScreen;
