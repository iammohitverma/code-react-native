import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const EditBankScreen = ({navigation}) => {
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Payment Method
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>
                
                <View style={ThemeStyle.pmSecHdr}>
                    <View style={ThemeStyle.pmSecBox}>
                        <Image
                            style={ThemeStyle.pmIconNrml}
                            source={require('../assets/credit_card_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconHdng}>
                            Bank
                        </Text>
                    </View>
                    {/* <View style={ThemeStyle.pmSecBoxRight}>
                        <Image
                            style={ThemeStyle.pmIconAdd}
                            source={require('../assets/add_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconSubdng}>
                            Add New Cards
                        </Text>
                    </View> */}
                </View>

                
                <View style={ThemeStyle.EditCardForm}>
                    <View style={ThemeStyle.EditCardFormLabel}>
                        <Text style={ThemeStyle.PaymentBankName}>
                            First Bank of Boston
                        </Text>
                        
                        <Image
                            style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                            source={require('../assets/delete_icon.png')}
                        />
                    </View>
                    <View>
                        <TextInput 
                        placeholder='*****'  
                        style={ThemeStyle.LoginInpt}> 
                        </TextInput>
                    </View>

                    <View>
                        <Pressable>
                            <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                <Text style={ThemeStyle.GradientBtnText}>Save Changes</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default EditBankScreen;
