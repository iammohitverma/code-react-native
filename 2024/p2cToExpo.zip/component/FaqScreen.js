import React, { useState } from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const FaqScreen = ({navigation}) => {
    const [accordianStatus, accordianStatusChange] = useState("none");

    jewelStyle = function(myColor) {
        return {
            borderRadius: 10,
            backgroundColor: myColor,
        }
    }

    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        FAQ
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>

                <View style={ThemeStyle.AccordianWrapper}>
                    <View style={ThemeStyle.AccordianBox}>

                        <Pressable style={ThemeStyle.AcrdHdngWrap} onPress={() => accordianStatusChange("FirstActive")}>
                            <Image
                                style={ThemeStyle.AcrdIcon}
                                source={require('../assets/faq_sending_money.png')}
                            />
                            <Text style={ThemeStyle.AcrdHdng}>
                                Sending money
                            </Text>
                            
                            <Image
                                style={ThemeStyle.AcrdDownIcon}
                                source={require('../assets/down-arrow.png')}
                            />
                        </Pressable>

                        {accordianStatus === 'FirstActive' ? 
                        
                        <View style={ThemeStyle.AcrdCntntWrap}>
                            <Text style={ThemeStyle.AcrdCntnt}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </Text>
                        </View>
                        
                        : <View></View> }

                    </View>

                    <View style={ThemeStyle.AccordianBox}>

                        <Pressable style={ThemeStyle.AcrdHdngWrap} onPress={() => accordianStatusChange("SecondActive")}>
                            <Image
                                style={ThemeStyle.AcrdIcon}
                                source={require('../assets/faq_receive_money.png')}
                            />
                            <Text style={ThemeStyle.AcrdHdng}>
                                Receiving money
                            </Text>
                            
                            <Image
                                style={ThemeStyle.AcrdDownIcon}
                                source={require('../assets/down-arrow.png')}
                            />
                        </Pressable>

                        {accordianStatus === 'SecondActive' ? 
                        
                        <View style={ThemeStyle.AcrdCntntWrap}>
                            <Text style={ThemeStyle.AcrdCntnt}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </Text>
                        </View>
                        
                        : <View></View> }

                    </View>

                    <View style={ThemeStyle.AccordianBox}>

                        <Pressable style={ThemeStyle.AcrdHdngWrap} onPress={() => accordianStatusChange("ThirdActive")}>
                            <Image
                                style={ThemeStyle.AcrdIcon}
                                source={require('../assets/faq_cancel.png')}
                            />
                            <Text style={ThemeStyle.AcrdHdng}>
                                Canceling a transfer
                            </Text>
                            
                            <Image
                                style={ThemeStyle.AcrdDownIcon}
                                source={require('../assets/down-arrow.png')}
                            />
                        </Pressable>

                        {accordianStatus === 'ThirdActive' ? 
                        
                        <View style={ThemeStyle.AcrdCntntWrap}>
                            <Text style={ThemeStyle.AcrdCntnt}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </Text>
                        </View>
                        
                        : <View></View> }

                    </View>

                    <View style={ThemeStyle.AccordianBox}>

                        <Pressable style={ThemeStyle.AcrdHdngWrap} onPress={() => accordianStatusChange("ForthActive")}>
                            <Image
                                style={ThemeStyle.AcrdIcon}
                                source={require('../assets/faq_manage_account.png')}
                            />
                            <Text style={ThemeStyle.AcrdHdng}>
                                Managing my account
                            </Text>
                            
                            <Image
                                style={ThemeStyle.AcrdDownIcon}
                                source={require('../assets/down-arrow.png')}
                            />
                        </Pressable>

                        {accordianStatus === 'ForthActive' ? 
                        
                        <View style={ThemeStyle.AcrdCntntWrap}>
                            <Text style={ThemeStyle.AcrdCntnt}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </Text>
                        </View>
                        
                        : <View></View> }

                    </View>

                    <View style={ThemeStyle.AccordianBox}>

                        <Pressable style={ThemeStyle.AcrdHdngWrap} onPress={() => accordianStatusChange("FifthActive")}>
                            <Image
                                style={ThemeStyle.AcrdIcon}
                                source={require('../assets/faq_technical_support.png')}
                            />
                            <Text style={ThemeStyle.AcrdHdng}>
                                Technical support
                            </Text>
                            
                            <Image
                                style={ThemeStyle.AcrdDownIcon}
                                source={require('../assets/down-arrow.png')}
                            />
                        </Pressable>

                        {accordianStatus === 'FifthActive' ? 
                        
                        <View style={ThemeStyle.AcrdCntntWrap}>
                            <Text style={ThemeStyle.AcrdCntnt}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
                            </Text>
                        </View>
                        
                        : <View></View> }

                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default FaqScreen;
