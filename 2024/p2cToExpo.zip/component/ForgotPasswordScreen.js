import React from 'react';
import {
    Text,
    View,
    Button,
    StyleSheet,
    Image,
    Pressable,
    TextInput,
    ImageBackground
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const ForgotPasswordScreen = ({navigation}) => {
    return(
        <View style={[ThemeStyle.paddingHorizontal15,{flex:1,justifyContent:'center'}]}>
            <View>
                <Image
                    style={ThemeStyle.FpLock}
                    source={require('../assets/lock.png')}
                />
                <Text style={[ThemeStyle.LoginHeading,{textAlign:'center',marginBottom:20}]}>FORGOT PASSWORD?</Text>
                <Text style={[ThemeStyle.LoginCntnt,{textAlign:'center'}]}>Enter the email address associated with your account.</Text>

                <View style={ThemeStyle.LoginFormBox}>
                    <Text style={ThemeStyle.LoginLabel}>Enter Email Address</Text>

                    <TextInput 
                    placeholder='Email'  
                    style={ThemeStyle.LoginInpt}> 
                    </TextInput>

                    <Pressable>
                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                            <Text style={ThemeStyle.GradientBtnText}>Reset Password</Text>
                        </ImageBackground>
                    </Pressable>
                </View>
                <Text style={ThemeStyle.RegisterText}>
                    Don't have an Account? Click here <Text style={{fontFamily:'Lato-Bold'}}  onPress={() => navigation.navigate('Register')}>REGISTER NOW</Text>
                </Text>
            </View>
        </View>
    )
}

export default ForgotPasswordScreen;
