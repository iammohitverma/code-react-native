import React, { useState } from "react";
import {
    Text,
    View,
    Button,
    StyleSheet,
    Image,
    Pressable,
    SafeAreaView, 
    ScrollView,
    Modal,
    Alert,
    TextInput,
    ImageBackground
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';

const FormUpdatePopUp = () => {
    const [updateFormVisible, updateFormModalVisible] = useState(false);
    return (
      <View style={ThemeStyle.ModalCenteredView}>
        <Modal
            animationType="slide"
            transparent={true}
            visible={updateFormVisible}
            onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            updateFormModalVisible(!updateFormVisible);
            }}
        >


            <View style={ThemeStyle.modalOverlay}>
                <View style={ThemeStyle.formUpdatePopup}>
                    <View style={ThemeStyle.formPopupBox}>
                        <View>
                            <Text style={ThemeStyle.formPopupHdng}>
                                Profile Details
                            </Text>
                        </View>
                        <View style={ThemeStyle.LoginFormBoxRow}>
                            <View style={ThemeStyle.Width50}>

                                <TextInput 
                                placeholder='John Doe'  
                                style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                </TextInput>
                            </View>
                            <View style={ThemeStyle.Width50}>

                                <TextInput 
                                placeholder='North Bottom'  
                                style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                </TextInput>
                            </View>
                        </View>

                        <View>

                            <TextInput 
                            placeholder='john@gmail.com'  
                            style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                            </TextInput>
                        </View>

                        <View>
                            <Pressable>
                                <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                    <Text style={ThemeStyle.GradientBtnText}>Update</Text>
                                </ImageBackground>
                            </Pressable>
                        </View>

                        <Pressable
                            style={[ThemeStyle.successClosebutton,ThemeStyle.updateClosebutton]}
                            onPress={() => updateFormModalVisible(!updateFormVisible)}
                            >
                                <Image
                                    style={ThemeStyle.successCloseImg}
                                    source={require('../assets/close_icon_dark.png')}
                                />
                            </Pressable>
                    </View>
                </View>
            </View>

          
        </Modal>
        <Button
        title="Card Deleted MOdal"
        onPress={() => updateFormModalVisible(true)}
        >
        </Button>
      </View>
    );
}

export default FormUpdatePopUp;