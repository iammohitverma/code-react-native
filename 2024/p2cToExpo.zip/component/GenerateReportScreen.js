import React, { useState } from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';
import { CheckBox, Icon } from 'react-native-elements';


const GenerateReportScreen = ({navigation}) => {
    const [reportSortOn, reportSortOnView] = useState("first");
    const [reportOrder, reportOrderView] = useState("first");
    const [reportDataRange, reportDataRangeView] = useState("first");
    const [reportOutputOrder, reportOutputOrderView] = useState("first");
    const [reportOutputMedium, reportOutputMediumView] = useState("first");
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Generate Report
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>

                <View style={ThemeStyle.ReportWrapper}>

                    <View style={[ThemeStyle.ReportRadioBoxes,ThemeStyle.mb_10]}>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.mb_10]}>
                            <Text style={ThemeStyle.RR_hdng}>Sort on</Text>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportSortOn === 'first' ?  true : false}
                                    onPress={() => reportSortOnView("first")}
                                />
                                <Text style={ThemeStyle.RadioText}>Transfer Amount</Text>
                            </View>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportSortOn === 'second' ?  true : false}
                                    onPress={() => reportSortOnView("second")}
                                />
                                <Text style={ThemeStyle.RadioText}>Pickup State</Text>
                            </View>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportSortOn === 'third' ?  true : false}
                                    onPress={() => reportSortOnView("third")}
                                />
                                <Text style={ThemeStyle.RadioText}>Pickup Zip Code</Text>
                            </View>
                        </View>
                    </View>

                    <View style={[ThemeStyle.ReportRadioBoxes,ThemeStyle.mb_10]}>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.mb_10]}>
                            <Text style={ThemeStyle.RR_hdng}>Order</Text>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOrder === 'first' ?  true : false}
                                    onPress={() => reportOrderView("first")}
                                />
                                <Text style={ThemeStyle.RadioText}>Low to High</Text>
                            </View>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOrder === 'second' ?  true : false}
                                    onPress={() => reportOrderView("second")}
                                />
                                <Text style={ThemeStyle.RadioText}>High to Low</Text>
                            </View>
                        </View>
                    </View>

                    <View style={[ThemeStyle.ReportRadioBoxes,ThemeStyle.mb_10]}>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.mb_10]}>
                            <Text style={ThemeStyle.RR_hdng}>Date Range</Text>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'first' ?  true : false}
                                    onPress={() => reportDataRangeView("first")}
                                />
                                <Text style={ThemeStyle.RadioText}>Last Year</Text>
                            </View>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_20]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'second' ?  true : false}
                                    onPress={() => reportDataRangeView("second")}
                                />
                                <Text style={ThemeStyle.RadioText}>Last Quarter</Text>
                            </View>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'third' ?  true : false}
                                    onPress={() => reportDataRangeView("third")}
                                />
                                <Text style={ThemeStyle.RadioText}>Last Month</Text>
                            </View>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'fourth' ?  true : false}
                                    onPress={() => reportDataRangeView("fourth")}
                                />
                                <Text style={ThemeStyle.RadioText}>This Year</Text>
                            </View>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_20]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'fifth' ?  true : false}
                                    onPress={() => reportDataRangeView("fifth")}
                                />
                                <Text style={ThemeStyle.RadioText}>This Quarter</Text>
                            </View>
                            <View style={[ThemeStyle.flex_1,ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportDataRange === 'sixth' ?  true : false}
                                    onPress={() => reportDataRangeView("sixth")}
                                />
                                <Text style={ThemeStyle.RadioText}>This Month</Text>
                            </View>
                        </View>
                    </View>

                    <View style={[ThemeStyle.ReportRadioBoxes,ThemeStyle.mb_10]}>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.mb_10]}>
                            <Text style={ThemeStyle.RR_hdng}>Output Format</Text>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex]}>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOutputOrder === 'first' ?  true : false}
                                    onPress={() => reportOutputOrderView("first")}
                                />
                                <Text style={ThemeStyle.RadioText}>Excel</Text>
                            </View>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC,ThemeStyle.MLM_5]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOutputOrder === 'second' ?  true : false}
                                    onPress={() => reportOutputOrderView("second")}
                                />
                                <Text style={ThemeStyle.RadioText}>Word</Text>
                            </View>
                        </View>
                    </View>

                    <View style={[ThemeStyle.ReportRadioBoxes,ThemeStyle.mb_10]}>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.mb_10]}>
                            <Text style={ThemeStyle.RR_hdng}>Date Range</Text>
                        </View>
                        <View style={[ThemeStyle.RRB_Flex,ThemeStyle.MLM_5]}>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOutputMedium === 'first' ?  true : false}
                                    onPress={() => reportOutputMediumView("first")}
                                />
                                <Text style={ThemeStyle.RadioText}>On Screen</Text>
                            </View>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOutputMedium === 'second' ?  true : false}
                                    onPress={() => reportOutputMediumView("second")}
                                />
                                <Text style={ThemeStyle.RadioText}>Print</Text>
                            </View>
                            <View style={[ThemeStyle.RRB_Flex,ThemeStyle.RRB_AC]}>
                                <CheckBox
                                    checkedIcon="dot-circle-o"
                                    uncheckedIcon="circle-o"
                                    size={16}
                                    checkedColor="#272728"
                                    checked={ reportOutputMedium === 'third' ?  true : false}
                                    onPress={() => reportOutputMediumView("third")}
                                />
                                <Text style={ThemeStyle.RadioText}>Download</Text>
                            </View>
                        </View>
                    </View>

                    <View style={ThemeStyle.mb_20}>
                        <Pressable>
                            <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                <Text style={ThemeStyle.GradientBtnText}>Generate Report</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>

                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default GenerateReportScreen;
