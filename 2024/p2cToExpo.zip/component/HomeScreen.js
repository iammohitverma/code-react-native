import React, { useState } from "react";
import {
    Text,
    View,
    Button,
    Image,
    Pressable,
    ImageBackground,
    TextInput,
    SafeAreaView,
    ScrollView,
    TouchableOpacity
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const HomeScreen = ({navigation}) => {
    return(
        <SafeAreaView>
            <ScrollView>
                <View>
                    <ImageBackground source={require('../assets/gradient_bg.png')} resizeMode="cover" style={ThemeStyle.profileBannerBg}>
                        <View style={ThemeStyle.mainBanner}>
                            <Text  style={[ThemeStyle.profileHdng,ThemeStyle.profileHdngAlign]}>Welcome</Text>

                            <View style={ThemeStyle.userImageWrapHome}>
                                <View style={[ThemeStyle.userImageWrapBox]}>
                                    <Image
                                        style={ThemeStyle.userImageHome}
                                        source={require('../assets/dummy_user.png')}
                                    />
                                </View>
                                <Text style={ThemeStyle.userNameHome}>John Doe</Text>
                            </View>

                            <TouchableOpacity hitSlop={{top: 10, bottom: 10, left: 10, right: 10}} style={ThemeStyle.closeIcon}  onPress={() => navigation.navigate('MainProfile')}>
                                <Image
                                    style={ThemeStyle.closeIconImg}
                                    source={require('../assets/bar.png')}
                                />
                            </TouchableOpacity>

                            <TouchableOpacity hitSlop={{top: 10, bottom: 10, left: 10, right: 10}} style={ThemeStyle.notificationIcon}>
                                <Image
                                    style={ThemeStyle.notificationIconImg}
                                    source={require('../assets/profileScreen/bell.png')}
                                />
                            </TouchableOpacity>
                        </View>
                    </ImageBackground>
                </View>

                <View style={ThemeStyle.CntntData}>
                    {/* User balance */}
                    <View style={ThemeStyle.UserBalance}>
                        <View style={ThemeStyle.UserBalance_Left}>
                            <Text style={ThemeStyle.UserBalance_hdng}>Funds Sent This Month</Text>
                            <Text style={ThemeStyle.UserBalance_cntnt}>$3,500.00</Text>
                        </View>
                        <View style={ThemeStyle.UserBalance_Right}>
                            <Text style={ThemeStyle.UserBalance_hdng}>Funds Sent This Year</Text>
                            <Text style={ThemeStyle.UserBalance_cntnt}>$12,600.00</Text>
                        </View>
                    </View>

                    {/* Last Five Transaction */}
                    <View style={ThemeStyle.LastTransaction}>

                        <View style={ThemeStyle.mt_20}>
                            <Text style={ThemeStyle.LastTransHdng}>
                                Last Five Transaction
                            </Text>
                        </View>
                    </View>

                    {/* Last Five Transaction List */}
                    <View style={ThemeStyle.LT_mainWrap}>
                        <View style={[ThemeStyle.LastTransFlex,ThemeStyle.TransListHdngBG]}>
                            <View style={ThemeStyle.LTL_50}>
                                <Text style={ThemeStyle.TransHdngText}>
                                    Date
                                </Text>
                            </View>
                            <View style={ThemeStyle.LTL_50}>
                                <Text style={ThemeStyle.TransHdngText}>
                                    Amount
                                </Text>
                            </View>
                        </View>

                        <View>
                            <View style={[ThemeStyle.LastTransFlex]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>

                            <View style={[ThemeStyle.LastTransFlex,ThemeStyle.LToddBG]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>

                            <View style={[ThemeStyle.LastTransFlex]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>

                            <View style={[ThemeStyle.LastTransFlex,ThemeStyle.LToddBG]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>

                            <View style={[ThemeStyle.LastTransFlex]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>

                            <View style={[ThemeStyle.LastTransFlex,ThemeStyle.LToddBG]}>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        09/01/21
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LTL_50}>
                                    <Text style={[ThemeStyle.TransHdngText,ThemeStyle.TransHdngTextSM]}>
                                        $200.00
                                    </Text>
                                </View>
                            </View>
                        </View>

                        <Pressable onPress={() => navigation.navigate('GenerateReport')}>
                            <ImageBackground source={require('../assets/report_bgsvg.png')} resizeMode="cover" style={[ThemeStyle.GradientBtnBox,ThemeStyle.ReportBtnHome]}>
                                <Text style={ThemeStyle.GradientBtnText}>Reports</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>

                    <View style={[ThemeStyle.HomeGoBtn,ThemeStyle.mt_20]}>
                        <View style={[ThemeStyle.HGB_half]}>
                            <Pressable  onPress={() => navigation.navigate('SendMoney')}>
                                <Image
                                    style={ThemeStyle.HGB_img_L}
                                    source={require('../assets/send_money_icon.png')}
                                />
                                <Text style={[ThemeStyle.HGB_text]}>
                                    Send Money
                                </Text>
                            </Pressable>
                        </View>
                        <View style={[ThemeStyle.HGB_half]}>
                            <Pressable  onPress={() => navigation.navigate('PickUpLocation')}>
                                <Image
                                    style={ThemeStyle.HGB_img_R}
                                    source={require('../assets/find_location_icon.png')}
                                />
                                <Text style={[ThemeStyle.HGB_text]}>
                                    Find Location
                                </Text>
                            </Pressable>
                        </View>
                    </View>

                    <View style={ThemeStyle.mt_20}>
                        <Text style={ThemeStyle.LastTransHdng}>
                            Payment Method
                        </Text>
                    </View>
                    
                    <View style={[ThemeStyle.spaceBetween]}>
                        <View style={ThemeStyle.PaymentCardWrapper}>
                            <Image source={require('../assets/card1_img.png')} style={ThemeStyle.cardsImg}>
                            </Image>
                        </View>
                        <View style={ThemeStyle.PaymentCardWrapper}>
                            <Image source={require('../assets/card2_img.png')} style={ThemeStyle.cardsImg}>
                            </Image>
                        </View>
                    </View>
                </View>

                

                <View style={[ThemeStyle.footerBar]}>
                        <View style={[ThemeStyle.footerBarEqual]}>
                            <Text style={[ThemeStyle.footerBarText]}>Payment Setting</Text>
                        </View>
                        <View style={[ThemeStyle.footerBarEqual]}>
                            <Text style={[ThemeStyle.footerBarText]}>Profile Setting</Text>
                        </View>
                        <View style={[ThemeStyle.footerBarEqual]}>
                            <Text style={[ThemeStyle.footerBarText]}>Help & Support</Text>
                        </View>
                    </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default HomeScreen;
