import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    Image,
    ImageBackground,
    TouchableOpacity
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const LoginScreen = ({navigation}) => {
    return(
        <View style={[ThemeStyle.paddingHorizontal15,{flex:1,justifyContent:'center'}]}>
            <View>
                <Text style={ThemeStyle.LoginHeading}>Sign In</Text>
                <Text style={ThemeStyle.LoginSubHdng}>WELCOME BACK :)</Text>
                <Text style={ThemeStyle.LoginCntnt}>To Keep Connected with us please login with your Personal information by email address and password.</Text>

                <View style={ThemeStyle.LoginFormBox}>
                    <Text style={ThemeStyle.LoginLabel}>Username</Text>

                    <TextInput 
                    placeholder='username'  
                    style={ThemeStyle.LoginInpt}> 
                    </TextInput>

                    <Text style={ThemeStyle.LoginLabel}>Password</Text>

                    <TextInput 
                    placeholder='password'  
                    secureTextEntry={true}
                    style={ThemeStyle.LoginInpt}> 
                    </TextInput>

                    <Pressable onPress={() => navigation.navigate('Home')}>
                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                            <Text style={ThemeStyle.GradientBtnText}>SIGN IN</Text>
                        </ImageBackground>
                    </Pressable>
                </View>
                <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('ForgotPassword')}>Forgot Password?</Text>
                <Text style={ThemeStyle.RegisterText}>
                    Don't have an Account? Click here <Text style={ThemeStyle.LinkStyle}> REGISTER NOW</Text>
                </Text>
            </View>
        </View>
    )
}

export default LoginScreen;
