import React, { useState }  from 'react';
import {
    Text,
    View,
    Button,
    Image,
    Pressable,
    ImageBackground,
    SafeAreaView, 
    ScrollView,
    TouchableOpacity
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';
import { Switch } from 'react-native-elements';


const MainProfileScreen = ({navigation}) => {

    const [checked, setChecked] = useState(false);

    const toggleSwitch = () => {
        setChecked(!checked);
    };
    return(
        <SafeAreaView>
            <ScrollView>
                <View>
                    <ImageBackground source={require('../assets/gradient_bg.png')} resizeMode="cover" style={ThemeStyle.profileBannerBg}>
                        <View style={ThemeStyle.mainBanner}>
                            <Text  style={ThemeStyle.profileHdngSecond}>Profile</Text>
                            <View style={ThemeStyle.userImageWrap}>
                                <Image
                                    style={ThemeStyle.userImage}
                                    source={require('../assets/dummy_user.png')}
                                />
                                <Pressable style={ThemeStyle.editIconWrap}>
                                    <Image
                                        style={ThemeStyle.editIcon}
                                        source={require('../assets/edit_icon.png')}
                                    />
                                </Pressable>
                            </View>
                            <Text  style={ThemeStyle.userName}>John Doe</Text>

                            <TouchableOpacity hitSlop={{top: 10, bottom: 10, left: 10, right: 10}}  style={ThemeStyle.closeIcon} onPress={() => navigation.goBack()}>
                                <Image
                                    style={ThemeStyle.closeIconImg}
                                    source={require('../assets/close_icon.png')}
                                />
                            </TouchableOpacity>

                            <TouchableOpacity hitSlop={{top: 10, bottom: 10, left: 10, right: 10}}  style={ThemeStyle.notificationIcon}>
                                <Image
                                    style={ThemeStyle.notificationIconImg}
                                    source={require('../assets/profileScreen/bell.png')}
                                />
                            </TouchableOpacity>
                        </View>
                    </ImageBackground>

                    <View style={{paddingHorizontal:15}}>
                        <View style={ThemeStyle.Cards}>
                            <Text style={ThemeStyle.subHdng}>
                                General
                            </Text>

                            <Pressable style={ThemeStyle.hdngWrap}  onPress={() => navigation.navigate('Profile')}>
                                <Text style={ThemeStyle.hdngText}>
                                    Personal Details
                                </Text>
                                <Text style={ThemeStyle.hdngCntnt}>
                                    You can edit your information about your email address, phone numbers or physical address.
                                </Text>
                            </Pressable>
                            
                            <View style={ThemeStyle.hdngWrap}>
                                <Text style={ThemeStyle.hdngText}>
                                    Change Password
                                </Text>
                            </View>

                            <View>
                                <Text style={ThemeStyle.hdngText}>
                                    Notifications
                                </Text>
                                <Text style={ThemeStyle.hdngCntnt}>
                                    Manage if you categories to create full control over your expenses and categories.
                                </Text>

                                <View style={ThemeStyle.switchAbso}>
                                    <Switch
                                        color="#272728"
                                        value={checked}
                                        onValueChange={(value) => setChecked(value)}
                                    />
                                </View>
                            </View>
                        </View>
                        
                        <View style={ThemeStyle.Cards}>
                            <Text style={ThemeStyle.subHdng}>
                                Another
                            </Text>

                            <View style={ThemeStyle.hdngWrap}>
                                <Text style={ThemeStyle.hdngText}  onPress={() => navigation.navigate('PickUpLocation')}>
                                    Find Location
                                </Text>
                            </View>
                            
                            <View style={ThemeStyle.hdngWrap}>
                                <Text style={ThemeStyle.hdngText}  onPress={() => navigation.navigate('Login')}>
                                    Login & Security
                                </Text>
                            </View>

                            <Pressable style={ThemeStyle.hdngWrap}  onPress={() => navigation.navigate('FaqScreen')}>
                                <Text style={ThemeStyle.hdngText}>
                                    FAQ & Help
                                </Text>
                            </Pressable>

                            <View style={ThemeStyle.hdngWrap}>
                                <Text style={ThemeStyle.hdngText} onPress={() => navigation.navigate('Contact')}>
                                    Contact
                                </Text>
                            </View>

                            <View>
                                <Text style={ThemeStyle.hdngText}>
                                    Logout
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default MainProfileScreen;
