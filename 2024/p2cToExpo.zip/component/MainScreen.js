import React from 'react';
import {
    Text,
    View,
    Button,
    Image,
    Pressable
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const MainScreen = ({navigation}) => {
    return(
        <View>
            <Image
                style={ThemeStyle.tinyLogo}
                source={require('../assets/heroImage.png')}
            />
            <View style={ThemeStyle.MainScreenWrapper}>
              <Text style={ThemeStyle.MainScreenHeading}>
                Welcome to 
                <Text style={ThemeStyle.Colored}> PIN2CASH</Text>
              </Text>

              <Text style={ThemeStyle.MainScreenSubHdng}>Send cash to anyone in the U.S</Text>
              
              <Pressable style={ThemeStyle.BorderdButton} onPress={() => navigation.navigate('Login')}>
                <Text style={ThemeStyle.ButtonText}>Sign In</Text>
              </Pressable>

              <Pressable style={ThemeStyle.BorderdButton} onPress={() => navigation.navigate('Register')}>
                <Text style={ThemeStyle.ButtonText}>Create An Account</Text>
              </Pressable>

              {/* <Pressable style={ThemeStyle.BorderdButton} onPress={() => navigation.navigate('AllScreenList')}> */}
              <Pressable style={ThemeStyle.BorderdButton} onPress={() => navigation.navigate('PickUpLocation')}>
                <Text style={ThemeStyle.ButtonText}>Find A Pickup Location</Text>
              </Pressable>
            </View>
        </View>
    )
}

export default MainScreen;
