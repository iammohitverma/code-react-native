import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const PaymentMethod = ({navigation}) => {
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Payment Method
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>
                
                <View style={ThemeStyle.pmSecHdr}>
                    <View style={ThemeStyle.pmSecBox}>
                        <Image
                            style={ThemeStyle.pmIconNrml}
                            source={require('../assets/credit_card_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconHdng}>
                            My Cards
                        </Text>
                    </View>
                    <Pressable style={ThemeStyle.pmSecBoxRight} onPress={() => navigation.navigate('AddCard')}>
                        <Image
                            style={ThemeStyle.pmIconAdd}
                            source={require('../assets/add_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconSubdng}>
                            Add New Cards
                        </Text>
                    </Pressable>
                </View>

                
                {/* Render this view in your flat list | this is for bank card */}
                <View style={ThemeStyle.PaymentCardFlex}>
                    <View style={ThemeStyle.PaymentCardWrapper}>
                        <Image source={require('../assets/card1_img.png')} style={ThemeStyle.cardsImg}>
                        </Image>
                        
                        <View style={ThemeStyle.PaymentCardIcons}>
                            <Pressable  onPress={() => navigation.navigate('EditCard')}>
                                <Image
                                    style={ThemeStyle.pmIconEdit}
                                    source={require('../assets/pencil_icon.png')}
                                />
                            </Pressable>
                            
                            <Image
                                style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                                source={require('../assets/delete_icon.png')}
                            />
                        </View>
                    </View>
                    <View style={ThemeStyle.PaymentCardWrapper}>
                        <Image source={require('../assets/card2_img.png')} style={ThemeStyle.cardsImg}>
                        </Image>
                        
                        <View style={ThemeStyle.PaymentCardIcons}>
                            <Pressable  onPress={() => navigation.navigate('EditCard')}>
                                <Image
                                    style={ThemeStyle.pmIconEdit}
                                    source={require('../assets/pencil_icon.png')}
                                />
                            </Pressable>
                            
                            <Image
                                style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                                source={require('../assets/delete_icon.png')}
                            />
                        </View>
                    </View>
                </View>

                <View style={ThemeStyle.PaymentCardFlex}>
                    <View style={ThemeStyle.PaymentCardWrapper}>
                        <Image source={require('../assets/card3_img.png')} style={ThemeStyle.cardsImg}>
                        </Image>
                        
                        <View style={ThemeStyle.PaymentCardIcons}>
                            <Pressable  onPress={() => navigation.navigate('EditCard')}>
                                <Image
                                    style={ThemeStyle.pmIconEdit}
                                    source={require('../assets/pencil_icon.png')}
                                />
                            </Pressable>
                            
                            <Image
                                style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                                source={require('../assets/delete_icon.png')}
                            />
                        </View>
                    </View>
                    <View style={ThemeStyle.PaymentCardWrapper}>
                        <Image source={require('../assets/card4_img.png')} style={ThemeStyle.cardsImg}>
                        </Image>
                        
                        <View style={ThemeStyle.PaymentCardIcons}>
                            <Pressable  onPress={() => navigation.navigate('EditCard')}>
                                <Image
                                    style={ThemeStyle.pmIconEdit}
                                    source={require('../assets/pencil_icon.png')}
                                />
                            </Pressable>
                            
                            <Image
                                style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                                source={require('../assets/delete_icon.png')}
                            />
                        </View>
                    </View>
                </View>
                {/* End */}
                
                <View style={[ThemeStyle.pmSecHdr,{marginTop:20}]}>
                    <View style={ThemeStyle.pmSecBox}>
                        <Image
                            style={ThemeStyle.pmIconNrml}
                            source={require('../assets/bank_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconHdng}>
                            Banks
                        </Text>
                    </View>
                    <View style={ThemeStyle.pmSecBoxRight}>
                        <Image
                            style={ThemeStyle.pmIconAdd}
                            source={require('../assets/add_icon.png')}
                        />
                        <Text style={ThemeStyle.cmnIconSubdng}>
                            Add New Bank
                        </Text>
                    </View>
                </View>

                {/* Render this view in your flat list | this is for banks list */}
                <View style={ThemeStyle.PaymentBankFlex}>
                    <View style={ThemeStyle.PaymentBankWrapper}>
                        <Text style={ThemeStyle.dotBankName}>

                        </Text>
                        <Text style={ThemeStyle.PaymentBankName}>
                            First Bank of Boston
                        </Text>
                        
                        <Pressable  onPress={() => navigation.navigate('EditBank')}>
                            <Image
                                style={ThemeStyle.pmIconEdit}
                                source={require('../assets/pencil_icon.png')}
                            />
                        </Pressable>
                        
                        <Image
                            style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                            source={require('../assets/delete_icon.png')}
                        />
                    </View>

                    <View style={ThemeStyle.PaymentBankWrapper}>
                        <Text style={ThemeStyle.dotBankName}>

                        </Text>
                        <Text style={ThemeStyle.PaymentBankName}>
                            Acme Credit Union
                        </Text>
                        
                        <Pressable  onPress={() => navigation.navigate('EditBank')}>
                            <Image
                                style={ThemeStyle.pmIconEdit}
                                source={require('../assets/pencil_icon.png')}
                            />
                        </Pressable>
                        
                        <Image
                            style={[ThemeStyle.pmIconEdit,ThemeStyle.pmIconDelete]}
                            source={require('../assets/delete_icon.png')}
                        />
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default PaymentMethod;
