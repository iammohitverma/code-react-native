import React from 'react';
import {
    Text,
    View,
    Button,
    StyleSheet,
    Image,
    Pressable,
    SafeAreaView, 
    ScrollView,
    TextInput,
    ImageBackground,
    TouchableOpacity
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const PickUpLocationScreen = ({navigation}) => {
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Find Location
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>
                    
                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>
                <View>
                    <Image
                        style={ThemeStyle.LocMapImg}
                        source={require('../assets/map_img.png')}
                    />
                    
                    <View style={ThemeStyle.PX_15}>
                        <View style={[ThemeStyle.LoginFormBoxRow,ThemeStyle.PX_15,ThemeStyle.mt_20]}>
                            <View style={ThemeStyle.Width30}>
                                <Text style={ThemeStyle.LoginLabel}>Within</Text>

                                <TextInput  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                            <View style={ThemeStyle.Width70}>
                                <Text style={ThemeStyle.LoginLabel}>MIles of</Text>

                                <TextInput 
                                placeholder='ZIP CODE OR CITY AND STATE'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                        </View>

                        <View style={ThemeStyle.mt_10}>
                            <Pressable>
                                <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                    <Text style={ThemeStyle.GradientBtnText}>Find Location</Text>
                                </ImageBackground>
                            </Pressable>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default PickUpLocationScreen;
