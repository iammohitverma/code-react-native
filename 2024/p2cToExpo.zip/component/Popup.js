import React, { useState } from "react";
import {
    Text,
    View,
    Button,
    StyleSheet,
    Image,
    Pressable,
    SafeAreaView, 
    ScrollView,
    Modal,
    Alert,
    TextInput,
    ImageBackground
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';

const Popup = () => {
    const [successVisible, successModalVisible] = useState(false);
    return (
      <View style={ThemeStyle.ModalCenteredView}>
        <Modal
        animationType="slide"
        transparent={true}
        visible={successVisible}
        onRequestClose={() => {
          Alert.alert("Modal has been closed.");
          successModalVisible(!successVisible);
        }}
      >


            <View style={ThemeStyle.modalOverlay}>
                <View style={ThemeStyle.successModalView}>
                    
                    <Image
                        style={ThemeStyle.successImage}
                        source={require('../assets/success_img.png')}
                    />

                    <Text style={ThemeStyle.successPopupText}>
                        Card deleted successfully
                    </Text>



                    <Pressable
                    style={ThemeStyle.successClosebutton}
                    onPress={() => successModalVisible(!successVisible)}
                    >
                        <Image
                            style={ThemeStyle.successCloseImg}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>
            </View>

          
        </Modal>
        <Button
        title="Card Deleted MOdal"
        onPress={() => successModalVisible(true)}
        >
        </Button>


        
        
      </View>
    );
}

export default Popup;