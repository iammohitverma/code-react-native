import React, { useState } from "react";
import {
    Text,
    View,
    Button,
    Image,
    Pressable,
    ImageBackground,
    Modal,
    Alert,
    TextInput
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const ProfileScreen = ({navigation}) => {
    const [successVisible, successModalVisible] = useState(false);
    const [profileUpdateFormVisible, profileUpdateFormModalVisible] = useState(false);
    const [addressUpdateFormVisible, addressUpdateFormModalVisible] = useState(false);
    const [passwordUpdateFormVisible, passwordUpdateFormModalVisible] = useState(false);
    return(
        <View>
            <ImageBackground source={require('../assets/gradient_bg.png')} resizeMode="cover" style={ThemeStyle.profileBannerBg}>
                <View style={ThemeStyle.mainBanner}>
                    <Text  style={ThemeStyle.profileHdng}>Profile</Text>
                    <View style={ThemeStyle.userImageWrap}>
                        <Image
                            style={ThemeStyle.userImage}
                            source={require('../assets/dummy_user.png')}
                        />
                        <Pressable style={ThemeStyle.editIconWrap}>
                            <Image
                                style={ThemeStyle.editIcon}
                                source={require('../assets/edit_icon.png')}
                            />
                        </Pressable>
                    </View>
                    <Text  style={ThemeStyle.userName}>John Doe</Text>

                    <Pressable style={ThemeStyle.closeIcon} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.closeIconImg}
                            source={require('../assets/close_icon.png')}
                        />
                    </Pressable>
                </View>
            </ImageBackground>

            <View>
                <Image
                    style={ThemeStyle.qrCode}
                    source={require('../assets/profileScreen/qr-code.png')}
                />
            </View>

            <View style={ThemeStyle.profileLinks}>
                <Pressable style={ThemeStyle.linkDetails} onPress={() => profileUpdateFormModalVisible(true)}>
                    <Image
                        style={ThemeStyle.linkIcon}
                        source={require('../assets/profileScreen/user-edit.png')}
                    />
                    <Text style={ThemeStyle.linkTitle}>
                        Profile Details
                    </Text>
                    <Image
                        style={ThemeStyle.linkIconArrow}
                        source={require('../assets/profileScreen/right-arrow.png')}
                    />
                </Pressable>


                <Pressable style={ThemeStyle.linkDetails} onPress={() => addressUpdateFormModalVisible(true)}>
                    <Image
                        style={ThemeStyle.linkIcon}
                        source={require('../assets/profileScreen/location-edit.png')}
                    />
                    <Text style={ThemeStyle.linkTitle}>
                        Address
                    </Text>
                    <Image
                        style={ThemeStyle.linkIconArrow}
                        source={require('../assets/profileScreen/right-arrow.png')}
                    />
                </Pressable>


                <Pressable style={ThemeStyle.linkDetails} onPress={() => passwordUpdateFormModalVisible(true)}>
                    <Image
                        style={ThemeStyle.linkIcon}
                        source={require('../assets/profileScreen/setting-edit.png')}
                    />
                    <Text style={ThemeStyle.linkTitle}>
                        Change Password
                    </Text>
                    <Image
                        style={ThemeStyle.linkIconArrow}
                        source={require('../assets/profileScreen/right-arrow.png')}
                    />
                </Pressable>


                <Pressable style={ThemeStyle.linkDetails} onPress={() => navigation.navigate('PaymentMethod')}>
                    <Image
                        style={ThemeStyle.linkIcon}
                        source={require('../assets/profileScreen/card-edit.png')}
                    />
                    <Text style={ThemeStyle.linkTitle}>
                        Payment Method
                    </Text>
                    <Image
                        style={ThemeStyle.linkIconArrow}
                        source={require('../assets/profileScreen/right-arrow.png')}
                    />
                </Pressable>
            </View>



            {/* Form Modals List */}
            {/* Profile Update Popup */}
            <View style={ThemeStyle.ModalCenteredView}>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={profileUpdateFormVisible}
                    onRequestClose={() => {
                    Alert.alert("Modal has been closed.");
                    profileUpdateFormModalVisible(!profileUpdateFormVisible);
                    }}
                >


                    <View style={ThemeStyle.modalOverlay}>
                        <View style={ThemeStyle.formUpdatePopup}>
                            <View style={ThemeStyle.formPopupBox}>
                                <View>
                                    <Text style={ThemeStyle.formPopupHdng}>
                                        Profile Details
                                    </Text>
                                </View>
                                <View style={ThemeStyle.LoginFormBoxRow}>
                                    <View style={ThemeStyle.Width50}>

                                        <TextInput 
                                        placeholder='John Doe'  
                                        style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                        </TextInput>
                                    </View>
                                    <View style={ThemeStyle.Width50}>

                                        <TextInput 
                                        placeholder='North Bottom'  
                                        style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                        </TextInput>
                                    </View>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='john@gmail.com'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>
                                    <Pressable onPress={() => successModalVisible(true)}>
                                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                            <Text style={ThemeStyle.GradientBtnText}>Update</Text>
                                        </ImageBackground>
                                    </Pressable>
                                </View>

                                <Pressable
                                    style={[ThemeStyle.successClosebutton,ThemeStyle.updateClosebutton]}
                                    onPress={() => profileUpdateFormModalVisible(!profileUpdateFormVisible)}
                                    >
                                        <Image
                                            style={ThemeStyle.successCloseImg}
                                            source={require('../assets/close_icon_dark.png')}
                                        />
                                </Pressable>
                            </View>
                        </View>
                    </View>

                
                </Modal>
            </View>

            
            {/* Address Update Popup */}
            <View style={ThemeStyle.ModalCenteredView}>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={addressUpdateFormVisible}
                    onRequestClose={() => {
                    Alert.alert("Modal has been closed.");
                    addressUpdateFormModalVisible(!addressUpdateFormVisible);
                    }}
                >


                    <View style={ThemeStyle.modalOverlay}>
                        <View style={ThemeStyle.formUpdatePopup}>
                            <View style={ThemeStyle.formPopupBox}>
                                <View>
                                    <Text style={ThemeStyle.formPopupHdng}>
                                        Update Address
                                    </Text>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='1234 Main Street'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='pin2cash9989'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='Los Angeles'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>
                                <View style={ThemeStyle.LoginFormBoxRow}>
                                    <View style={ThemeStyle.Width50}>

                                        <TextInput 
                                        placeholder='California'  
                                        style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                        </TextInput>
                                    </View>
                                    <View style={ThemeStyle.Width50}>

                                        <TextInput 
                                        placeholder='90011'  
                                        style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                        </TextInput>
                                    </View>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='+91-98789845645'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>
                                    <Pressable onPress={() => successModalVisible(true)}>
                                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                            <Text style={ThemeStyle.GradientBtnText}>Update Address</Text>
                                        </ImageBackground>
                                    </Pressable>
                                </View>

                                <Pressable
                                    style={[ThemeStyle.successClosebutton,ThemeStyle.updateClosebutton]}
                                    onPress={() => addressUpdateFormModalVisible(!addressUpdateFormVisible)}
                                    >
                                        <Image
                                            style={ThemeStyle.successCloseImg}
                                            source={require('../assets/close_icon_dark.png')}
                                        />
                                    </Pressable>
                            </View>
                        </View>
                    </View>

                
                </Modal>
            </View>

                        
            {/* Address Update Popup */}
            <View style={ThemeStyle.ModalCenteredView}>
                <Modal
                    animationType="slide"
                    transparent={true}
                    visible={passwordUpdateFormVisible}
                    onRequestClose={() => {
                    Alert.alert("Modal has been closed.");
                    passwordUpdateFormModalVisible(!passwordUpdateFormVisible);
                    }}
                >


                    <View style={ThemeStyle.modalOverlay}>
                        <View style={ThemeStyle.formUpdatePopup}>
                            <View style={ThemeStyle.formPopupBox}>
                                <View>
                                    <Text style={ThemeStyle.formPopupHdng}>
                                        Change Password
                                    </Text>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='1234 Main Street'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>

                                    <TextInput 
                                    placeholder='pin2cash9989'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.UpdateInpt]}> 
                                    </TextInput>
                                </View>

                                <View>
                                    <Pressable onPress={() => successModalVisible(true)}>
                                        <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                            <Text style={ThemeStyle.GradientBtnText}>Update Password</Text>
                                        </ImageBackground>
                                    </Pressable>
                                </View>

                                <Pressable
                                    style={[ThemeStyle.successClosebutton,ThemeStyle.updateClosebutton]}
                                    onPress={() => passwordUpdateFormModalVisible(!passwordUpdateFormVisible)}
                                    >
                                        <Image
                                            style={ThemeStyle.successCloseImg}
                                            source={require('../assets/close_icon_dark.png')}
                                        />
                                    </Pressable>
                            </View>
                        </View>
                    </View>

                
                </Modal>
            </View>
            
            <Modal
                animationType="fade"
                transparent={true}
                visible={successVisible}
                onRequestClose={() => {
                Alert.alert("Modal has been closed.");
                successModalVisible(!successVisible);
                }}
            >


                <View style={ThemeStyle.modalOverlay}>
                    <View style={ThemeStyle.successModalView}>
                        
                        <Image
                            style={ThemeStyle.successImage}
                            source={require('../assets/success_img.png')}
                        />

                        <Text style={ThemeStyle.successPopupText}>
                            Update successfully
                        </Text>



                        <Pressable
                        style={ThemeStyle.successClosebutton}
                        onPress={() => successModalVisible(!successVisible)}
                        >
                            <Image
                                style={ThemeStyle.successCloseImg}
                                source={require('../assets/close_icon_dark.png')}
                            />
                        </Pressable>
                    </View>
                </View>

            
            </Modal>
        </View>
    )
}

export default ProfileScreen;
