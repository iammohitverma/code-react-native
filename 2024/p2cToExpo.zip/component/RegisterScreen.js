import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const LoginScreen = ({navigation}) => {
    return(
        <SafeAreaView style={ThemeStyle.container}>
            <ScrollView>
                <View style={[ThemeStyle.paddingHorizontal15,{flex:1,justifyContent:'center'}]}>
                    <View>
                        <Text style={[ThemeStyle.LoginHeading,{marginBottom:20}]}>Sign Up</Text>
                        <Text style={ThemeStyle.LoginCntnt}>You will need to upload a photo ID to create an account.</Text>

                        {/**  Register Screen Input field **/}
                        <View style={ThemeStyle.LoginFormBoxRow}>
                            <View style={ThemeStyle.Width50}>
                                <Text style={ThemeStyle.LoginLabel}>First Name*</Text>

                                <TextInput 
                                placeholder='*****'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                            <View style={ThemeStyle.Width50}>
                                <Text style={ThemeStyle.LoginLabel}>Last Name*</Text>

                                <TextInput 
                                placeholder='*****'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                        </View>

                        <View>
                            <Text style={ThemeStyle.LoginLabel}>Email Address*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>

                        <View>
                            <Text style={ThemeStyle.LoginLabel}>Mailing Address*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>

                        <View>
                            <Text style={ThemeStyle.LoginLabel}>Address Line 2*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>

                        <View>
                            <Text style={ThemeStyle.LoginLabel}>City*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>

                        <View style={ThemeStyle.LoginFormBoxRow}>
                            <View style={ThemeStyle.Width50}>
                                <Text style={ThemeStyle.LoginLabel}>State*</Text>

                                <TextInput 
                                placeholder='*****'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                            <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Zip*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                            </View>
                        </View>

                        <View>
                            <Text style={ThemeStyle.LoginLabel}>Phone*</Text>

                            <TextInput 
                            placeholder='*****'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>

                        <View style={ThemeStyle.LoginFormBoxRow}>
                            <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Password*</Text>

                                <TextInput 
                                placeholder='*****'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                            <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Confirm Password</Text>

                                <TextInput 
                                placeholder='*****'  
                                style={ThemeStyle.LoginInpt}> 
                                </TextInput>
                            </View>
                        </View>

                        <View>
                            <Pressable>
                                <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                    <Text style={ThemeStyle.GradientBtnText}>Register</Text>
                                </ImageBackground>
                            </Pressable>
                        </View>
                        <Text style={ThemeStyle.frgtPswrdText}  onPress={() => navigation.navigate('ForgotPassword')}>Forgot Password?</Text>
                        <Text style={ThemeStyle.RegisterText}>
                            Already have an Account? Click here 
                            <Text style={ThemeStyle.LinkStyle}  onPress={() => navigation.navigate('Login')}> Login</Text>
                        </Text>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default LoginScreen;
