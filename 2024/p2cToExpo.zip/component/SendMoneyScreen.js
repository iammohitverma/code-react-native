import React, { useState } from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    SafeAreaView, 
    ScrollView,
    ImageBackground,
    Image,
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';
import { CheckBox, Icon } from 'react-native-elements';


const SendMoneyScreen = ({navigation}) => {
    const [cardCheck, cardSetCheck] = useState("first");
    const [bankCheck, bankSetCheck] = useState("first");
    const [pickupCheck, pickupSetCheck] = useState("first");
    return(
        <SafeAreaView>
            <ScrollView>
                <View style={ThemeStyle.ScreenHeaders}>
                    <Text style={ThemeStyle.headerHdng}>
                        Send Money
                    </Text>

                    <Pressable style={ThemeStyle.hdrBackIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrBackIcon}
                            source={require('../assets/left-arrow.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrBarIconWrap} onPress={() => navigation.navigate('MainProfile')}>
                        <Image
                            style={ThemeStyle.hdrBarIcon}
                            source={require('../assets/bar_dark.png')}
                        />
                    </Pressable>

                    <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                        <Image
                            style={ThemeStyle.hdrCloseIcon}
                            source={require('../assets/close_icon_dark.png')}
                        />
                    </Pressable>
                </View>

                <View style={[ThemeStyle.EditCardForm,{marginTop:0}]}>
                    <View style={ThemeStyle.LoginFormBoxRow}>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Amount</Text>
                            <TextInput 
                            placeholder='California'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Confirm Amount</Text>
                            <TextInput 
                            placeholder='90011'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>
                    </View>

                    {/* Send Money From */}
                    <View style={[ThemeStyle.SendMoneyFromWrapper,ThemeStyle.mb_10]}>
                        <Text style={ThemeStyle.SendMoneyFromHdng}>
                            Send Money From
                        </Text>

                        {/* Send Money From Credit Card */}
                        <View>
                            <Text style={ThemeStyle.SendMoneyFromSubHdng}>
                                Credit Card
                            </Text>

                            <View style={[ThemeStyle.SendMoneyCardBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox01}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ cardCheck === 'first' ?  true : false}
                                        onPress={() => cardSetCheck("first")}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardImgBox01}>
                                    <Image
                                        style={[ThemeStyle.SMcardImg]}
                                        source={require('../assets/card_01_icon.png')}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardInputBox}>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMcardInput]}> 
                                    </TextInput>
                                </View>
                            </View>

                            <View style={[ThemeStyle.SendMoneyCardBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox01}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ cardCheck === 'second' ? true : false }
                                        onPress={() => cardSetCheck("second")}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardImgBox01}>
                                    <Image
                                        style={[ThemeStyle.SMcardImg]}
                                        source={require('../assets/card_02_icon.png')}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardInputBox}>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMcardInput]}> 
                                    </TextInput>
                                </View>
                            </View>

                            <View style={[ThemeStyle.SendMoneyCardBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox01}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ cardCheck === 'third' ? true : false }
                                        onPress={() => cardSetCheck("third")}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardImgBox01}>
                                    <Image
                                        style={[ThemeStyle.SMcardImg]}
                                        source={require('../assets/card_02_icon.png')}
                                    />
                                </View>
                                <View style={ThemeStyle.SMcardInputBox}>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMcardInput]}> 
                                    </TextInput>
                                </View>
                            </View>
                        </View>

                        {/* Send Money From Bank */}
                        <View>
                            <Text style={ThemeStyle.SendMoneyFromSubHdng}>
                                Bank
                            </Text>

                            <View style={[ThemeStyle.SendMoneyBankBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox02}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ bankCheck === 'first' ?  true : false}
                                        onPress={() => bankSetCheck("first")}
                                    />
                                    <Text style={ThemeStyle.SMbankName}>
                                        Test Bank
                                    </Text>
                                </View>
                                <View style={ThemeStyle.SMbankInputBox}>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMcardInput]}> 
                                    </TextInput>
                                </View>
                            </View>

                            <View style={[ThemeStyle.SendMoneyBankBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox02}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ bankCheck === 'second' ?  true : false}
                                        onPress={() => bankSetCheck("second")}
                                    />
                                    <Text style={ThemeStyle.SMbankName}>
                                        First Bank of Boston
                                    </Text>
                                </View>
                                <View style={ThemeStyle.SMbankInputBox}>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMcardInput]}> 
                                    </TextInput>
                                </View>
                            </View>
                        </View>
                    </View>

                    {/* Send Money To */}
                    <View style={[ThemeStyle.SendMoneyFromWrapper,ThemeStyle.mb_10]}>
                        <Text style={ThemeStyle.SendMoneyFromHdng}>
                            Send Money To
                        </Text>

                        <View>
                            <Text style={ThemeStyle.SendMoneyFromSubHdng}>
                                Location to Pickup
                            </Text>
                        </View>

                        <View>
                            <View style={ThemeStyle.PickUpWrap}>
                                <View style={ThemeStyle.PickUpWrapLeft}>
                                    <View style={ThemeStyle.SMradioBox02}>
                                        <CheckBox
                                            checkedIcon="dot-circle-o"
                                            uncheckedIcon="circle-o"
                                            size={18}
                                            checkedColor="#272728"
                                            checked={ pickupCheck === 'first' ?  true : false}
                                            onPress={() => pickupSetCheck("first")}
                                        />
                                        <Text style={ThemeStyle.SMPickupHdng}>
                                            Within
                                        </Text>
                                    </View>
                                    <View style={ThemeStyle.SMPickupInput}>
                                        {/* Select Box */}
                                    </View>
                                </View>
                                <View style={ThemeStyle.PickUpWrapRight}>
                                    <Text style={ThemeStyle.SMPickupHdng}>
                                        Miles of
                                    </Text>
                                    <TextInput 
                                    placeholder='*****'  
                                    style={[ThemeStyle.LoginInpt,ThemeStyle.SMPickupInput]}> 
                                    </TextInput>
                                </View>
                            </View>

                            <View style={[ThemeStyle.SendMoneyBankBox,ThemeStyle.mb_10]}>
                                <View style={ThemeStyle.SMradioBox02}>
                                    <CheckBox
                                        checkedIcon="dot-circle-o"
                                        uncheckedIcon="circle-o"
                                        size={18}
                                        checkedColor="#272728"
                                        checked={ pickupCheck === 'second' ?  true : false}
                                        onPress={() => pickupSetCheck("second")}
                                    />
                                    <Text style={ThemeStyle.SMbankName}>
                                        Bank Account
                                    </Text>
                                </View>
                                <View style={[ThemeStyle.SMbankInputBox,ThemeStyle.LoginFormBoxRow]}>
                                    <View style={ThemeStyle.Width50}>
                                        <TextInput 
                                            placeholder='123456'  
                                            style={ThemeStyle.LoginInpt}> 
                                        </TextInput>
                                    </View>
                                    <View style={ThemeStyle.Width50}>
                                        <TextInput 
                                        placeholder='123456'  
                                        style={ThemeStyle.LoginInpt}> 
                                        </TextInput>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>

                    <View>
                        <Pressable>
                            <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={[ThemeStyle.GradientBtnBox,ThemeStyle.seeFeeGradientBtnBox]}>
                                <Text style={ThemeStyle.GradientBtnText}>See Fee</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>

                    <View style={[ThemeStyle.LoginFormBoxRow,ThemeStyle.mt_20]}>
                        <View style={ThemeStyle.Width50}>
                            <Text style={ThemeStyle.LoginLabel}>Fee</Text>

                            <TextInput 
                            placeholder='123456'  
                            style={ThemeStyle.LoginInpt}> 
                            </TextInput>
                        </View>
                        <View style={ThemeStyle.Width50}>
                        <Text style={ThemeStyle.LoginLabel}>Total</Text>

                        <TextInput 
                        placeholder='123456'  
                        style={ThemeStyle.LoginInpt}> 
                        </TextInput>
                        </View>
                    </View>

                    <View style={ThemeStyle.borderBtm}>
                        <Text style={ThemeStyle.smallText}>
                            1. Your credit card company may charge a cash advance fee and interest
                        </Text>
                        <Text style={ThemeStyle.smallText}>
                            2. Timing of funds depends on your bank’s hours of operation and funds policy
                        </Text>
                    </View>

                    <View>
                        <Text style={ThemeStyle.SendMoneyFromHdng}>
                            Send Money
                        </Text>
                    </View>

                    <View>
                        <Text style={ThemeStyle.smallText}>
                        By clicking SEND MONEY you agree to this website’s Terms and Conditions and authorize Pin2Cash to deduct the Amount specified above from the bank account linked to the debit card listed in your account information.
                        </Text>
                    </View>

                    <View style={[ThemeStyle.mt_20,ThemeStyle.mb_20]}>
                        <Pressable>
                            <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                                <Text style={ThemeStyle.GradientBtnText}>Send Money</Text>
                            </ImageBackground>
                        </Pressable>
                    </View>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default SendMoneyScreen;
