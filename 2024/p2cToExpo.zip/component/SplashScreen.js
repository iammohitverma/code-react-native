import React, { useState } from "react";
import {
    Text,
    View,
    Image,
    ImageBackground,
    SafeAreaView,
    Button
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';
import Animated, { Keyframe, Easing } from 'react-native-reanimated';


const SplashScreen = ({navigation}) => {

    const setTmOt = () => {
        setTimeout(function(){
            navigation.replace('Main')
        }, 6000)
    }

    const enteringAnimation = new Keyframe({
      0: {
        transform: [{ scale: 5 }],
      },
      100: {
        transform: [{ scale: 1 }],
        easing: Easing.quad,
      },
    }).duration(1000);
    

    const enteringAnimationIcon2 = new Keyframe({
        0: {
            opacity:0
        },
        100: {
            opacity:1,
            easing: Easing.quad,
        },
      }).duration(1000).delay(1000);
    

      const enteringAnimationIconParent = new Keyframe({
          0: {
            transform: [{ scale: 2 }],
          },
          50: {
            transform: [{ scale: 1 }],
            easing: Easing.quad,
          }
        }).duration(1000).delay(2000);
    
        const enteringAnimationIconParent01 = new Keyframe({
            0: {
              transform: [{ translateX: 0 }],
            },
            50: {
              transform: [{ translateX: -120 }],
              easing: Easing.quad,
            }
          }).duration(1500).delay(3000);
    
          const enteringAnimationLogoMain = new Keyframe({
              0: {
                opacity:0
              },
              50: {
                opacity:1,
                easing: Easing.quad,
              }
            }).duration(1500).delay(4000);



    return(
        <SafeAreaView>
            <ImageBackground source={require('../assets/spashBackground.png')} resizeMode="cover" style={ThemeStyle.splashBackground}>   

                <Animated.View
                        entering={enteringAnimationIconParent01}
                    >
                    <Animated.View
                        entering={enteringAnimationIconParent}
                    >
                        <Animated.View
                            entering={enteringAnimation}
                            style={{
                                height:"100%",
                                width:"100%",
                                display:"flex",
                                justifyContent:"center",
                                alignItems:"center",
                            }}
                        >
                            <Image
                                style={ThemeStyle.icon1SL}
                                source={require('../assets/splash_icon_01.png')}
                            />

                            <Animated.View
                                entering={enteringAnimationIcon2}
                                style={ThemeStyle.icon2SL}
                            >
                                <Image
                                    style={ThemeStyle.icon2SLImg}
                                    source={require('../assets/splash_icon_02.png')}
                                />
                            </Animated.View>
                            


                            <Animated.View
                                entering={enteringAnimationLogoMain}
                            >
                                <View>
                                    <Image
                                        style={ThemeStyle.LogoSL}
                                        source={require('../assets/splash_logo.png')}
                                    />
                                </View>
                            </Animated.View>
                                
                        </Animated.View>
                    </Animated.View>
                </Animated.View>

            </ImageBackground>  

            {setTmOt()}
        </SafeAreaView>
    )
}

export default SplashScreen;
