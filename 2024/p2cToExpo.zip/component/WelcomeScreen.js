import React from 'react';
import {
    Text,
    View,
    Button,
    Pressable,
    TextInput,
    Image,
    ImageBackground
} from 'react-native';
import ThemeStyle from './stylesheet/ThemeStyle';


const WelcomeScreen = ({navigation}) => {
    return(
        <View style={[ThemeStyle.paddingHorizontal15,{paddingVertical:25}]}>
            <View style={ThemeStyle.LogoBox}>
                <Image
                    style={ThemeStyle.LogoImage}
                    source={require('../assets/logo.png')}
                />

                <Pressable style={ThemeStyle.hdrCloseIconWrap} onPress={() => navigation.goBack()}>
                    <Image
                        style={ThemeStyle.hdrCloseIcon}
                        source={require('../assets/close_icon_dark.png')}
                    />
                </Pressable>
            </View>
            <View>
                <Text style={ThemeStyle.LoginSubHdng}>WELCOME BACK!</Text>
                <Text style={ThemeStyle.welcomeSubHdng}>Pin2Cash is a secure way to send money to a friend, relative, or anyone else.</Text>

                <Text style={ThemeStyle.welcomeBlueCntnt}>Whether or not they have an ID</Text>


                <Pressable>
                    <ImageBackground source={require('../assets/bgGradient.png')} resizeMode="cover" style={ThemeStyle.GradientBtnBox}>
                        <Text style={ThemeStyle.GradientBtnText}>Login to Continue</Text>
                    </ImageBackground>
                </Pressable>
                
                <Text style={ThemeStyle.RegisterText}>
                    Don't have an Account? Click here 
                    <Text style={ThemeStyle.LinkStyle}  onPress={() => navigation.navigate('Register')}> REGISTER NOW</Text>
                </Text>
            </View>
        </View>
    )
}

export default WelcomeScreen;
