import {
    StyleSheet,
} from 'react-native';

const ThemeStyle = StyleSheet.create({
    splashBackground: {
        width: "100%",
        height: "100%",
    },
    tinyLogo: {
        width: 390,
        height: 395,
    },
    MainScreenWrapper: {
        paddingHorizontal: 33,
    },
    MainScreenHeading: {
        fontSize: 30,
        marginTop: 30,
        color: "#272728",
        textAlign: "center",
        fontWeight: "bold",
        fontFamily: 'LatoBlack'
    },
    Colored: {
        color: "#0D65DB"
    },
    MainScreenSubHdng: {
        fontSize: 14,
        color: "#272728",
        textAlign: "center",
        marginTop: 6,
        fontFamily: 'Lato-Bold'
    },
    BorderdButton: {
        borderWidth: 1,
        borderRadius: 25,
        backgroundColor: "transparent",
        paddingVertical: 12.5,
        marginTop: 20,
    },
    ButtonText: {
        textAlign: 'center',
        fontSize: 15,
        color: "#272728",
        fontFamily: 'LatoBlack'
    },
    paddingHorizontal15: {
        paddingHorizontal: 15,
    },
    LoginHeading: {
        fontSize: 24,
        color: '#272728',
        marginBottom: 40,
        textTransform: 'uppercase',
        fontFamily: 'LatoBlack'
    },
    LoginSubHdng: {
        fontSize: 24,
        color: '#272728',
        marginBottom: 20,
        textTransform: 'uppercase',
        fontFamily: 'LatoBlack'
    },
    LoginCntnt: {
        fontSize: 14,
        color: '#272728',
        marginBottom: 40,
        textTransform: 'capitalize',
        fontFamily: 'Lato-Regular'
    },
    LoginFormBox: {

    },
    LoginLabel: {
        fontSize: 14,
        color: '#272728',
        marginBottom: 10,
        textTransform: 'capitalize',
        fontFamily: 'Lato-Bold'
    },
    LoginInpt: {
        borderRadius: 10,
        height: 45,
        backgroundColor: "#eeeeee",
        marginBottom: 15,
        paddingHorizontal: 10,
        fontSize: 14,
        color: '#6C757D',
    },
    frgtPswrdText: {
        textAlign: 'center',
        marginTop: 10,
        color: "#272728",
        fontFamily: 'Lato-Bold',
        fontSize: 13,
    },
    RegisterText: {
        textAlign: 'center',
        marginTop: 10,
        color: "#272728",
        fontFamily: 'Lato-Normal',
        fontSize: 13,
    },
    FpLock: {
        width: 89,
        height: 83,
        marginLeft: "auto",
        marginRight: "auto",
    },
    LinkStyle: {
        fontFamily: 'Lato-Bold',
        // borderBottomWidth: 0,
        // borderBottomColor: '#000',
        color: "#272728",
        fontSize: 12,
    },
    GradientBtnBox: {
        padding: 15,
        borderRadius: 50,
        overflow: 'hidden',
    },
    GradientBtnText: {
        textAlign: "center",
        color: "#fff",
        fontSize: 14,
        fontFamily: 'Lato-Bold',
        textTransform: 'uppercase',
    },
    container: {
        paddingVertical: 20,
    },
    LoginFormBoxRow: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    Width50: {
        width: "48%",
    },
    profileBannerBg: {
        height: 248,
        width: "100%",
        borderBottomEndRadius: 30,
        borderBottomStartRadius: 30,
        overflow: 'hidden',
    },
    profileHdng: {
        color: '#fff',
        textAlign: 'center',
        fontSize: 16,
        marginTop: 15,
    },
    userImageWrap: {
        position: "relative",
        width: 110,
        height: 110,
        marginLeft: "auto",
        marginRight: "auto",
    },
    userImage: {
        width: 110,
        height: 110,
        borderRadius: 55,
        borderWidth: 3,
        borderColor: '#fff',
        marginTop: 20,
        overflow: "hidden",
    },
    editIconWrap: {
        width: 30,
        height: 30,
        backgroundColor: "#1E79BB",
        position: "absolute",
        right: -7,
        bottom: 0,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 25,
    },
    editIcon: {
        width: 12,
        height: 12,
    },
    userName: {
        textAlign: "center",
        color: '#fff',
        fontSize: 26,
        fontFamily: 'Lato-Bold',
        marginTop: 40,
    },
    qrCode: {
        width: 150,
        height: 150,
        marginTop: 30,
        marginLeft: "auto",
        marginRight: "auto",
    },
    profileLinks: {
        paddingHorizontal: 30,
        marginTop: 20,
    },
    linkDetails: {
        display: 'flex',
        flexDirection: "row",
        alignItems: "center",
        marginTop: 10,
    },
    linkIcon: {
        width: 30,
        height: 30,
    },
    linkTitle: {
        fontSize: 16,
        color: "#272728",
        marginLeft: 10,
    },
    linkIconArrow: {
        width: 13,
        height: 13,
        marginLeft: 'auto',
    },
    mainBanner: {
        position: "relative",
    },
    closeIcon: {
        position: "absolute",
        left: 10,
        top: 20,
        width: 13,
        height: 13,
    },
    closeIconImg: {
        width: 13,
        height: 13,
    },
    profileHdngSecond: {
        color: '#fff',
        textAlign: 'left',
        fontSize: 16,
        marginTop: 15,
        marginLeft: 40,
    },
    notificationIcon: {
        position: "absolute",
        right: 10,
        top: 20,
        width: 15,
        height: 15,
    },
    notificationIconImg: {
        width: 15,
        height: 15,
    },
    Cards: {
        padding: 10,
        backgroundColor: "#EAF3FE",
        marginTop: 15,
    },
    subHdng: {
        color: "#272728",
        fontSize: 12,
        fontFamily: 'Lato-Bold',
        marginBottom: 10,
    },
    hdngWrap: {
        paddingBottom: 9,
        marginBottom: 9,
        borderBottomWidth: 1,
        borderBottomColor: "#d4dde8"
    },
    hdngText: {
        fontSize: 14,
        color: "#272728",
        fontFamily: 'LatoBlack',
        marginBottom: 5,
    },
    switchAbso: {
        position: "absolute",
        right: 0,
        top: -5,
    },
    hdngCntnt: {
        color: "#272728",
        fontSize: 12,
        fontFamily: 'Lato-Regular',
    },
    ScreenHeaders: {
        position: 'relative',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: "#d4dde8",
        marginHorizontal: 15,
        marginBottom: 15,
    },
    headerHdng: {
        textAlign: "center",
        fontSize: 20,
        color: "#272728",
        fontFamily: 'LatoBlack',
    },
    hdrBackIconWrap: {
        position: "absolute",
        left: 0,
        top: 13,
        width: 20,
        height: 20,
    },
    hdrBackIcon: {
        width: 20,
        height: 20,
    },
    hdrCloseIconWrap: {
        position: "absolute",
        right: 0,
        top: -5,
        width: 20,
        height: 20,
        padding: 20,
    },
    hdrCloseIcon: {
        width: 17,
        height: 17,
    },
    hdrBarIconWrap: {
        position: "absolute",
        left: 30,
        top: 15,
        width: 20,
        height: 20,
    },
    hdrBarIcon: {
        width: 19,
        height: 15,
    },
    ContactWrap: {
        paddingHorizontal: 15,
    },
    cntctSubText: {
        color: "#272728",
        fontSize: 13,
        fontFamily: 'Lato-Regular',
        marginBottom: 5,
    },
    cntctMainText: {
        color: "#272728",
        fontFamily: 'LatoBlack',
        marginBottom: 20,
        fontSize: 15,
    },
    ContactCheckBoxes: {
        display: 'flex',
        flexDirection: "row",
        alignItems: "center",
        marginLeft: -15,
        marginBottom: -15
    },
    ContactLabel: {
        fontSize: 14,
        color: '#272728',
        marginBottom: 10,
        textTransform: 'capitalize',
        fontFamily: 'Lato-Bold'
    },
    ContactInpt: {
        borderRadius: 10,
        height: 45,
        backgroundColor: "#eeeeee",
        marginBottom: 15,
        paddingHorizontal: 10,
        fontSize: 14,
        color: '#6C757D',
    },
    ContactTA: {
        height: 120,
        backgroundColor: "#eeeeee",
        marginBottom: 15,
        paddingHorizontal: 10,
        fontSize: 14,
        color: '#6C757D',
        textAlignVertical: 'top',
    },
    PaymentCardFlex: {
        diplay: "flex",
        flexDirection: "row",
        paddingHorizontal: 15,
        justifyContent: "space-between",
        marginBottom: 10,
    },
    PaymentCardWrapper: {
        width: "49%",
        borderRadius: 10,
        overflow: "hidden",
        position: "relative",
    },
    PaymentCardIcons: {
        diplay: "flex",
        flexDirection: "row",
        position: "absolute",
        top: 0,
        right: 0,
    },
    cardsImg: {
        width: "100%",
        height: 115,

    },
    pmSecHdr: {
        display: "flex",
        flexDirection: "row",
        paddingHorizontal: 17,
        marginBottom: 15,
    },
    pmSecBox: {
        flex: 1,
        display: "flex",
        flexDirection: "row",
        alignItems: "center"
    },
    pmSecBoxRight: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "flex-end",
        alignItems: "center"
    },
    pmIconNrml: {
        width: 20,
        height: 20,
        marginRight: 5,
    },
    pmIconAdd: {
        width: 15,
        height: 15,
        marginRight: 5,
    },
    cmnIconHdng: {
        fontFamily: 'Lato-Bold',
        fontSize: 15,
        color: "#272728",
    },
    cmnIconSubdng: {
        fontFamily: 'Lato-Bold',
        fontSize: 13,
        color: "#272728",
    },
    PaymentBankFlex: {
        paddingHorizontal: 15,
    },
    PaymentBankWrapper: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 30,
        marginTop: 10,
    },
    dotBankName: {
        width: 13,
        height: 13,
        backgroundColor: "#B9B9B9",
        marginRight: 10,
        borderRadius: 6.5,
    },
    PaymentBankName: {
        fontFamily: 'Lato-Bold',
        fontSize: 15,
        color: "#272728",
        marginRight: 20,
        width: 160,
    },
    pmIconEdit: {
        width: 30,
        height: 30,
    },
    EditPaymentCardFlex: {
        paddingHorizontal: 15,
    },
    EditPaymentCardWrapper: {
        position: 'relative',
    },
    EditPaymentCardIcons: {
        top: 5,
    },
    EditCardsImg: {
        width: "100%",
        height: 243,
    },
    EditpmIconDelete: {
        width: 50,
        height: 50
    },
    EditCardForm: {
        paddingHorizontal: 15,
        marginTop: 20,
    },
    EditCardFormLabel: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 20
    },
    LogoBox: {
        marginBottom: 50
    },
    LogoImage: {
        width: 200,
        height: 50,
        marginLeft: "auto",
        marginRight: "auto",
    },
    welcomeSubHdng: {
        fontFamily: 'Lato-Bold',
        fontSize: 15,
        color: "#272728",
        marginBottom: 15,
    },
    welcomeBlueCntnt: {
        color: "#0860E5",
        fontFamily: 'Lato-Bold',
        fontSize: 15,
        marginBottom: 30,
    },
    // Success Modal Style
    modalOverlay: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#000000aa",
    },
    successImage: {
        width: 50,
        height: 50,
    },
    successModalView: {
        backgroundColor: "#fff",
        borderRadius: 20,
        padding: 35,
        alignItems: "center",
        width: 300,
        shadowColor: "#000",
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5
    },
    successPopupText: {
        fontSize: 18,
        color: "#272728",
        fontFamily: 'LatoBlack',
        marginTop: 20,
    },
    successClosebutton: {
        width: 13,
        height: 13,
        position: 'absolute',
        right: 10,
        top: 10
    },
    successCloseImg: {
        width: 13,
        height: 13,
        opacity: 0.5
    },
    formUpdatePopup: {
        backgroundColor: "#EAF3FE",
        width: "100%",
        bottom: 0,
        position: "absolute",
        paddingHorizontal: 15,
        paddingVertical: 20,
    },
    formPopupHdng: {
        fontSize: 18,
        textAlign: "center",
        marginBottom: 25,
        color: "#272728",
        fontFamily: 'LatoBlack',
        borderBottomWidth: 1,
        borderColor: "#d9d9d9",
        paddingBottom: 10,
    },
    UpdateInpt: {
        backgroundColor: "#fff",
    },
    updateClosebutton: {
        top: 0,
    },
    SendMoneyFromWrapper: {
        borderColor: "#6C757D42",
        borderWidth: 1,
        paddingHorizontal: 12,
        paddingVertical: 10,
    },
    SendMoneyFromHdng: {
        fontSize: 20,
        color: '#272728',
        fontFamily: 'LatoBlack',
        marginBottom: 15,
    },
    SendMoneyFromSubHdng: {
        color: '#272728',
        fontSize: 14,
        fontFamily: 'Lato-Bold',
        marginBottom: 10,
    },
    SendMoneyCardBox: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center"
    },
    SMradioBox01: {
        width: "17%",
        textAlign: "left"
    },
    SMcardImgBox01: {
        width: "15%",
    },
    SMcardInputBox: {
        width: "68%",
    },
    SMcardImg: {
        // marginLeft: "auto",
        // marginRight: "auto",
        width: 35,
        height: 25,
    },
    SMcardInput: {
        marginBottom: 0,
    },
    SendMoneyBankBox: {

    },
    SMradioBox02: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center"
    },
    SMbankName: {
        color: "#272728",
        fontSize: 13,
        fontFamily: 'Lato-Bold',
    },
    SMbankInputBox: {
        width: "94%",
        marginLeft: "auto"
    },
    mb_10: {
        marginBottom: 10,
    },
    PickUpWrap: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    PickUpWrapLeft: {
        width: "49%",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    PickUpWrapRight: {
        width: "50%",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },
    PickUpWrapRightText: {
        width: "30%",
    },
    SMPickupInput: {
        width: "65%",
    },
    SMPickupHdng: {
        fontSize: 12,
        color: "#272728",
        fontFamily: 'Lato-Bold',
    },
    seeFeeGradientBtnBox: {
        width: "40%",
        borderRadius: 10,
    },
    mt_20: {
        marginTop: 20,
    },
    mb_20: {
        marginBottom: 20,
    },
    smallText: {
        fontSize: 12,
        fontFamily: 'Lato-Bold',
        color: "#272728",
    },
    borderBtm: {
        borderBottomWidth: 1,
        borderBottomColor: "#d4dde8",
        paddingBottom: 15,
        marginBottom: 15,
    },
    profileHdngAlign: {
        textAlign: "left",
        marginLeft: 40,
    },
    userImageWrapHome: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        marginTop: 20,
        paddingHorizontal: 15
    },
    userImageWrapBox: {
        position: "relative",
        width: 64,
        height: 64,
    },
    userImageHome: {
        width: 64,
        height: 64,
        borderRadius: 55,
        borderWidth: 1,
        borderColor: '#fff',
    },
    userNameHome: {
        color: "#fff",
        fontSize: 20,
        fontFamily: 'Lato-Bold',
        marginLeft: 20,
    },
    CntntData: {
        backgroundColor: "#fff",
        padding: 15,
        marginTop: -110,
        borderTopLeftRadius: 15,
        borderTopRightRadius: 15,
    },
    UserBalance: {
        display: "flex",
        flexDirection: "row",
        paddingVertical: 10,
        backgroundColor: "#EAF3FE",
        borderRadius: 10,
    },
    UserBalance_Left: {
        width: "50%",
        paddingHorizontal: 16,
        paddingVertical: 7,
    },
    UserBalance_Right: {
        width: "50%",
        borderLeftWidth: 1,
        borderLeftColor: "#B7D7FE",
        paddingHorizontal: 16,
        paddingVertical: 7,
    },
    UserBalance_hdng: {
        fontSize: 14,
        color: "#272728",
        fontFamily: 'Lato-Bold',
        marginBottom: 12,
    },
    UserBalance_cntnt: {
        fontSize: 14,
        color: "#272728",
        fontFamily: 'LatoBlack',
    },
    LastTransHdng: {
        color: '#272728',
        fontFamily: 'Lato-Bold',
        fontSize: 14,
    },
    ListBox: {
        marginHorizontal: 0,
        paddingHorizontal: 0
    },
    LastTransFlex: {
        display: "flex",
        flexDirection: "row",
    },
    LTL_50: {
        flex: 1
    },
    TransListHdngBG: {
        backgroundColor: "#EAF3FE",
    },
    TransHdngText: {
        fontSize: 14,
        color: "#272728",
        fontFamily: 'Lato-Bold',
        textAlign: "center",
        paddingVertical: 6,
    },
    TransHdngTextSM: {
        fontSize: 12,
    },
    LToddBG: {
        backgroundColor: "#F5F7F9",
    },
    ReportBtnHome: {
        paddingVertical: 10,
        borderRadius: 0,
    },
    LT_mainWrap: {
        borderRadius: 10,
        overflow: "hidden",
        marginTop: 10,
    },
    HomeGoBtn: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
    },
    HGB_half: {
        backgroundColor: "#EAF3FE",
        paddingVertical: 15,
        width: "48%",
        borderRadius: 10,
    },
    HGB_img_L: {
        width: 40,
        height: 40,
        marginLeft: "auto",
        marginRight: "auto",
    },
    HGB_img_R: {
        width: 35,
        height: 42,
        marginLeft: "auto",
        marginRight: "auto",
    },
    HGB_text: {
        textAlign: "center",
        fontSize: 14,
        color: "#272728",
        marginTop: 10,
        fontFamily: 'Lato-Bold',
    },
    spaceBetween: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 10,
    },
    footerBar: {
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
        backgroundColor: "#EAF3FE",
    },
    footerBarEqual: {
        flex: 1,
        paddingVertical: 10,
    },
    footerBarText: {
        color: "#272728",
        fontSize: 14,
        fontFamily: 'Lato-Bold',
        textAlign: "center",
    },
    ReportWrapper: {
        paddingHorizontal: 15,
    },
    ReportRadioBoxes: {
        marginBottom: 15,
        borderWidth: 1,
        borderColor: "#6C757D42",
        paddingBottom: 5,
    },
    RRB_Flex: {
        display: 'flex',
        flexDirection: 'row',
    },
    flex_1: {
        flex: 1
    },
    RR_hdng: {
        fontSize: 15,
        color: "#272728",
        fontFamily: 'LatoBlack',
        paddingTop: 15,
        paddingLeft: 15,
    },
    RRB_AC: {
        alignItems: "center",
    },
    flex_40: {
        width: "40%",
    },
    RadioText: {
        color: "#272728",
        fontSize: 14,
        fontFamily: 'Lato-Bold',
        marginLeft: -10,
    },
    MLM_5: {
        marginLeft: -5,
    },
    MLM_20: {
        marginLeft: -20,
    },
    AccordianWrapper: {
        paddingHorizontal: 15,
    },
    AccordianBox: {
        marginBottom: 20,
    },
    AcrdHdngWrap: {
        display: "flex",
        alignItems: "center",
        flexDirection: "row",
        backgroundColor: "#EEEEEE",
        borderRadius: 10,
        paddingHorizontal: 15,
        paddingVertical: 10
    },
    AcrdHdng: {
        color: "#272728",
        fontSize: 14,
        fontFamily: 'Lato-Bold',
        marginLeft: 20
    },
    AcrdIcon: {
        width: 28,
        height: 28,
    },
    AcrdCntntWrap: {
        backgroundColor: "#EEEEEE",
        borderRadius: 10,
        paddingHorizontal: 15,
        paddingVertical: 10,
        marginTop: 10
    },
    AcrdCntnt: {
        color: "#5c5c5c",
        fontSize: 13,
        fontFamily: 'Lato-Normal',
        lineHeight: 18,
    },
    AcrdDownIcon: {
        width: 15,
        height: 10,
        position: "absolute",
        right: 20,
    },
    PX_15: {
        paddingHorizontal: 15,
    },
    LocMapImg: {
        width: "100%",
    },
    Width30: {
        width: "30%",
        paddingRight: 10,
    },
    Width70: {
        width: "70%",
        paddingLeft: 10,
    },
    mt_10: {
        marginTop: 10,
    },
    icon1SL: {
        width: 80,
        height: 80,
    },
    icon2SL: {
        position: "absolute",
        left: "47.5%",
        top: "48.3%",
        width: 20,
        height: 24,
    },
    icon2SLImg: {
        width: 20,
        height: 24,
    },
    LogoSL: {
        width: 228,
        height: 80,
        position: "absolute",
        left: 45,
        top: -80,
        // opacity: 0,
    }
})

export default ThemeStyle;