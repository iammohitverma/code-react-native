import React, { useState } from "react";
import { View, StatusBar, Image, StyleSheet } from "react-native";
import Animated, { Keyframe } from "react-native-reanimated";
import { WebView } from "react-native-webview";

const App = () => {
  const [isWebViewLoaded, setIsWebViewLoaded] = useState(false);

  const leftToRightAnimation = new Keyframe({
    0: { opacity: 0 },
    50: { opacity: 0 },
    100: { opacity: 1 },
  }).duration(1200);

  const rightToLeftAnimation = new Keyframe({
    0: { opacity: 0, transform: [{ translateX: 100 }] },
    100: { opacity: 1, transform: [{ translateX: 0 }] },
  })
    .duration(1500)
    .delay(1200);

  return (
    <View style={{ flex: 1 }}>
      <StatusBar backgroundColor="#000" barStyle="light-content" />
      {!isWebViewLoaded && (
        <View style={styles.splashContainer}>
          <Animated.View entering={leftToRightAnimation}>
            <Image
              style={styles.icon}
              source={require("./assets/techmind-logo-icon.png")}
              resizeMode="contain"
            />
          </Animated.View>
          <Animated.View entering={rightToLeftAnimation}>
            <Image
              style={styles.text}
              source={require("./assets/techmind-logo-text.png")}
              resizeMode="contain"
            />
          </Animated.View>
        </View>
      )}
      <WebView
        source={{ uri: "https://techmind.co.in/" }}
        style={{ flex: 1, display: isWebViewLoaded ? "flex" : "none" }}
        onLoad={() => setIsWebViewLoaded(true)}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  splashContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "#fff",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
  },
  icon: {
    height: 70,
    width: 70,
  },
  text: {
    height: 100,
    width: 200,
  },
});

export default App;
