import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import { mvStyles } from "./MohitStyle";

const logo = require("../assets/images/headerLogo.png");
const hamburger = require("../assets/images/hamburger.png");
const cartIcon = require("../assets/images/bag.png");

export default function Header() {
  return (
    <View style={mvStyles.headerWrap}>
      <TouchableOpacity>
        <Image
          style={{ height: 20, width: 30 }}
          source={hamburger}
          resizeMode="contain"
        />
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          style={{ height: 25, width: 25 }}
          source={logo}
          resizeMode="contain"
        />
      </TouchableOpacity>
      <TouchableOpacity>
        <Image
          style={{ height: 25, width: 25 }}
          source={cartIcon}
          resizeMode="contain"
        />
      </TouchableOpacity>
    </View>
  );
}
