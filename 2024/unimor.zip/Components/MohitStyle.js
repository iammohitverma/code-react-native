import { StyleSheet } from "react-native";

export const mvStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "red",
  },
  screenWrapper: {
    flex: 1,
    padding: 15,
  },
  positionRelative: {
    position: "relative",
  },
  positionAbsolute: {
    position: "absolute",
  },
  splashWrapper: {
    flex: 1,
    backgroundColor: "#eaedf4",
    justifyContent: "center",
    alignItems: "center",
  },
  flexRow: {
    flexDirection: "row",
  },
  p_15: {
    padding: 15,
  },
  headerWrap: {
    padding: 15,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "nowrap",
  },
  banner: {
    minHeight: 250,
    justifyContent: "center",
    alignItems: "flex-start",
    backgroundColor: "#EBF2FF",
    paddingVertical: 50,
    paddingHorizontal: 20,
  },
  adBanner: {
    minHeight: 100,
    justifyContent: "center",
    alignItems: "flex-start",
    backgroundColor: "#EBF2FF",
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  primaryColor: {
    color: "#192639",
  },
  pt_40: {
    paddingTop: 40,
  },
  pb_40: {
    paddingBottom: 40,
  },
  py_40: {
    paddingVertical: 40,
  },
  pt_20: {
    paddingTop: 20,
  },
  pb_20: {
    paddingBottom: 20,
  },
  py_20: {
    paddingVertical: 20,
  },
  px_20: {
    paddingHorizontal: 20,
  },
  px_10: {
    paddingHorizontal: 10,
  },
  mb_15: {
    marginBottom: 15,
  },
  mr_10: {
    marginRight: 10,
  },
  mr_15: {
    marginRight: 15,
  },
  fs_14_400: {
    fontSize: 14,
    color: "#192639",
    fontFamily: "Hind-Regular",
    marginBottom: 5,
  },
  fw_600: {
    fontFamily: "Hind-Bold",
  },
  fs_22_600: {
    fontSize: 22,
    color: "#192639",
    fontFamily: "Hind-SemiBold",
    marginBottom: 5,
  },
  textCenter: {
    textAlign: "center",
  },
  whiteBtn: {
    fontSize: 16,
    paddingVertical: 15,
    paddingHorizontal: 30,
    backgroundColor: "#fff",
    color: "#192639",
    marginTop: 5,
    fontFamily: "Hind-SemiBold",
    borderRadius: 6,
  },
  categoriesWrap: {
    paddingHorizontal: 20,
  },
  imageBox: {
    backgroundColor: "#F6F8FB",
    marginBottom: 10,
    flexGrow: 1,
  },
  imageFull: {
    width: "100%",
    height: "100%",
  },
  w_100px: {
    width: 100,
  },
  h_100px: {
    height: 100,
  },
  w_200px: {
    width: 200,
  },
  h_200px: {
    height: 200,
  },
  w_160px: {
    width: 160,
  },
  h_160px: {
    height: 160,
  },
  productBtns: {
    top: 0,
    right: 0,
  },
  productBtn: {
    backgroundColor: "#F6F8FB",
    padding: 7,
    marginBottom: 5,
    elevation: 2,
  },
});
