import { SafeAreaView, View, Image } from "react-native";
import Animated, { Keyframe } from "react-native-reanimated";
import Statusbar from "../Statusbar";
import { mvStyles } from "../MohitStyle";

const logo = require("../../assets/images/logo.png");
function SplashScreen() {
  const logoAnimation = new Keyframe({
    0: { opacity: 0, transform: [{ scale: 4 }] },
    100: { opacity: 1, transform: [{ scale: 1 }] },
  })
    .duration(1500)
    .delay(0);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <Statusbar barBackground="#eaedf4" />
      <View style={mvStyles.splashWrapper}>
        <Animated.View entering={logoAnimation} style={mvStyles.splashWrapper}>
          <Image
            style={{ height: 100, width: 250 }}
            source={logo}
            resizeMode="contain"
          />
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

export default SplashScreen;
