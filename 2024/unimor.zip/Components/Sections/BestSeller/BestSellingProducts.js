import { View, Text, FlatList, TouchableOpacity } from "react-native";
import { mvStyles } from "../../MohitStyle";
import { ProductCard } from "../ProductCard";

function BestSellingProducts() {
  const products = [
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Bar stool",
      price: "$24.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Table lamp",
      price: "$50.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Decor",
      price: "$36.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Chairs",
      price: "$14.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Decor",
      price: "$36.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Chairs",
      price: "$14.00",
    },
  ];
  return (
    <View style={[mvStyles.py_20, mvStyles.px_20]}>
      <Text style={[mvStyles.fs_22_600, mvStyles.textCenter, mvStyles.mb_15]}>
        Best Sellers
      </Text>
      <FlatList
        data={products}
        renderItem={({ item, index }) => {
          return (
            <ProductCard key={index} item={item} width={160} height={160} />
          );
        }}
        keyExtractor={(item, index) => index}
        numColumns={2}
      />
    </View>
  );
}

export default BestSellingProducts;
