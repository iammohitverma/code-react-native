import { View, Text, TouchableOpacity, ImageBackground } from "react-native";
import { mvStyles } from "../../MohitStyle";

const adBanner = require("../../../assets/images/adBanner.jpg");

function Banner() {
  return (
    <View>
      <ImageBackground
        source={adBanner}
        resizeMode="cover"
        style={mvStyles.banner}
      >
        <Text style={mvStyles.fs_22_600}>Take 50% off now!</Text>
        <TouchableOpacity>
          <Text style={mvStyles.whiteBtn}>SHOP NOW</Text>
        </TouchableOpacity>
      </ImageBackground>
    </View>
  );
}

export default Banner;
