import { View, Text, FlatList, Image, TouchableOpacity } from "react-native";
import { mvStyles } from "../../MohitStyle";

const wishlistIcon = require("../../../assets/images/wishlist.png");

function FeaturedProducts() {
  const products = [
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Bar stool",
      price: "$24.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Table lamp",
      price: "$50.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: " Decor Decor Decor Decor Decor Decor Decor Decor ",
      price: "$36.00",
    },
    {
      featuredImage: require("../../../assets/images/dummy_product.jpg"),
      title: "Chairs",
      price: "$14.00",
    },
  ];
  return (
    <View style={[mvStyles.py_40, mvStyles.px_20]}>
      <View style={mvStyles.flexRow}>
        <Text style={[mvStyles.fs_22_600, { flex: 1 }]}>Best sellers</Text>
        <TouchableOpacity style={{ flex: 1 }}>
          <Text style={[mvStyles.fs_14_400, { textAlign: "right" }]}>
            View all
          </Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={products}
        renderItem={({ item, index }) => {
          return <ProductBox key={index} item={item} />;
        }}
        keyExtractor={(item, index) => index}
      />
    </View>
  );
}

export default FeaturedProducts;

// ProductBox Component for Flatlist
export function ProductBox({ item }) {
  return (
    <View style={[mvStyles.positionRelative, mvStyles.mr_15]}>
      <TouchableOpacity>
        <View style={[mvStyles.flexRow, { paddingRight: 30 }]}>
          <View style={[mvStyles.imageBox, mvStyles.w_100px, mvStyles.h_100px]}>
            <Image
              style={mvStyles.imageFull}
              source={item.featuredImage}
              resizeMode="contain"
            />
          </View>
          <View style={[mvStyles.px_10, { flexShrink: 1 }]}>
            <Text style={[mvStyles.fs_14_400]}>{item.title}</Text>
            <Text style={[mvStyles.fs_14_400, mvStyles.fw_600]}>
              {item.price}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
      <View style={[mvStyles.positionAbsolute, mvStyles.productBtns]}>
        <TouchableOpacity style={mvStyles.productBtn}>
          <Image
            style={{ height: 20, width: 20 }}
            source={wishlistIcon}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}
