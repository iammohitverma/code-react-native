import { View, Text, Image, TouchableOpacity } from "react-native";
import { mvStyles } from "../MohitStyle";

const wishlistIcon = require("../../assets/images/wishlist.png");
const cartIcon = require("../../assets/images/bag.png");

export function ProductCard({ item, width, height }) {
  const cwidth = width || 200;
  const cheight = height || 200;
  return (
    <View style={[mvStyles.positionRelative, mvStyles.mr_10, { flexGrow: 1 }]}>
      <TouchableOpacity>
        <View style={[mvStyles.imageBox]} width={cwidth} height={cheight}>
          <Image
            style={mvStyles.imageFull}
            source={item.featuredImage}
            resizeMode="contain"
          />
        </View>
        <Text style={mvStyles.fs_14_400}>{item.title}</Text>
        <Text style={[mvStyles.fs_14_400, mvStyles.fw_600]}>{item.price}</Text>
      </TouchableOpacity>
      <View style={[mvStyles.positionAbsolute, mvStyles.productBtns]}>
        <TouchableOpacity style={mvStyles.productBtn}>
          <Image
            style={{ height: 20, width: 20 }}
            source={wishlistIcon}
            resizeMode="contain"
          />
        </TouchableOpacity>
        <TouchableOpacity style={mvStyles.productBtn}>
          <Image
            style={{ height: 20, width: 20 }}
            source={cartIcon}
            resizeMode="contain"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}
