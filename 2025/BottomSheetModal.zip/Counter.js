import { View, Text, StyleSheet } from 'react-native'

const Counter = ({ count }) => {
    return (
        <View>
            <Text style={styles.textCenter}>{count}</Text>
        </View>
    )
}

export default Counter;

const styles = StyleSheet.create({
    textCenter: {
        textAlign: 'center',
        marginBottom: 20
    }
})