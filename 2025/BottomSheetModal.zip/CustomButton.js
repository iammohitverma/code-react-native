import { View, Text, Button } from 'react-native'
import React from 'react'

const CustomButton = ({ add }) => {
    return (
        <View>
            <Button title='add' onPress={add} />
        </View>
    )
}

export default CustomButton