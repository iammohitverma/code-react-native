import { createContext, useState } from "react";

export const CounterCtx = createContext({
    count: '',
    updateCounter: () => { },
});

function CountUpdateProvider({ children }) {
    const [count, setCount] = useState(0);

    function updateCounter() {
        console.log('update counter fired!');
        setCount((preVal) => {
            console.log(preVal + 1);
            return preVal + 1;
        });
    }

    const value = {
        count,
        updateCounter
    }

    return <CounterCtx.Provider value={value}>{children}</CounterCtx.Provider>
}

export default CountUpdateProvider;